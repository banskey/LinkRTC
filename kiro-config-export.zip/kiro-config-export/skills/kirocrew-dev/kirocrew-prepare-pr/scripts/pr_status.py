#!/usr/bin/env python3
"""pr_status.py - the decisive PR-readiness gate for the kirocrew-prepare-pr skill.

Prints PR state + every CI check + advisory unresolved-thread count and returns
an exit code that drives the poll loop. The aggregate ``PR Readiness`` status is
one signal folded with the rows, never an override of them: its FAILURE blocks
and its PENDING waits, but its green does not clear an observed failing or
pending row, because its context name is a forgeable display string.
Stdlib only; portable.

Usage:  python3 pr_status.py [pr-number] [--readiness-context NAME]
                             [--reviewers NAME1,NAME2] [--json]
        python3 pr_status.py --disposition-gate --repo OWNER/NAME --pr N
                             --head SHA
        python3 pr_status.py --supersession-gate --repo OWNER/NAME --pr N
                             --head SHA
        (no number -> auto-detect the PR for the current branch;
         --readiness-context / PREPARE_PR_READINESS_CONTEXT override the
         aggregate status-context name, default "PR Readiness";
         --reviewers / PREPARE_PR_REVIEWERS pin the reviewer fleet: only the
         named stamps are evaluated AND each named reviewer must have a fresh
         stamp; by default, every ``[<NAME>-REVIEWED]`` stamp found in bot
         comments is held to freshness, and absence is not required;
         --json appends one machine-readable object as the LAST line of stdout
         and changes nothing else -- same exit codes, same prose. Its
         ``progress_key`` sub-object is the only part safe to compare between
         runs; a monitoring loop uses it to tell a stalled PR from a moving one;
         --disposition-gate evaluates the disposition rule for an explicitly
         given repo/PR/head and also reports ``unpublished`` (whole-design
         lanes that still owe this head a verdict); it prints one JSON object
         and exits 0 --
         this is what pr-readiness.yml calls to enforce the rule server-side,
         so the rule keeps a single definition;
         --supersession-gate reports which verdicts for that head a later
         sample at the SAME head replaced, read out of the comment's stored
         edit history, and prints one JSON object and exits 0 on the same
         terms: ``ok`` false is UNKNOWN and must be treated as pending)

Exit codes:
   0  CLEAN     - open, non-draft, MERGEABLE, no CHANGES_REQUESTED, aggregate
                  PR Readiness (or the legacy full rollup) passed with no
                  observed failing row (a passed aggregate does not clear a
                  failing row), every reviewer stamp matches the current head,
                  no [BLOCK-MERGE] marker for the current head, and a
                  pull_request-event run exists for the current head (when the
                  repo uses Actions)
  10  RUNNING   - a required check is still queued/in-progress, or mergeability
                  has not been computed yet
  20  BLOCKED   - failing readiness, merge conflict, draft, CHANGES_REQUESTED,
                  a terminal PR state (MERGED/CLOSED), a stale reviewer stamp,
                  a blocking review marker on the current head, no
                  pull_request-event run for the current head, a disposition
                  comment violating the one-lane / one-rationale-per-finding
                  rule, an unanswered whole-design CONCERNS verdict for the
                  current head (local loop only -- --disposition-gate and the
                  required status are unchanged), a superseded verdict (a lane
                  blocked this head in a sample a later one replaced), or
                  anything that cannot be confirmed
   2  ENV ERROR - gh missing or not authenticated, or PR not found
"""

import importlib.machinery
import importlib.util
import json
import os
import re
import subprocess
import sys
import time


class _NoBytecodeSourceLoader(importlib.machinery.SourceFileLoader):
    """Load shipped source normally while suppressing cache writes."""

    def get_code(self, fullname):
        path = self.get_filename(fullname)
        source = self.get_data(path)
        return self.source_to_code(source, path)

    def set_data(self, path, data, *, _mode=0o666):
        return None


def _load_sibling(filename, name):
    """Load a sibling script without cwd, sys.path, or bytecode side effects."""
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
    loader = _NoBytecodeSourceLoader(name, path)
    spec = importlib.util.spec_from_loader(name, loader)
    if spec is None:  # pragma: no cover - defensive
        raise RuntimeError("cannot import kirocrew-prepare-pr sibling script: " + path)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return module


_review_contract = _load_sibling("_review_contract.py", "_prepare_pr_review_contract")
# Imported, never shelled out to: a subprocess would give this script a second
# way to fail (PATH, interpreter, quoting) for information it already has the
# code for, and the exit-code contract belongs to green_age.py's own CLI.
_green_age = _load_sibling("green_age.py", "_prepare_pr_green_age")
REVIEWED_STAMP_RE = _review_contract.REVIEWED_STAMP_RE
BLOCK_MERGE_RE = _review_contract.BLOCK_MERGE_RE
DEFAULT_MARKER_AUTHORS = _review_contract.DEFAULT_MARKER_AUTHORS
DEFAULT_MARKER_BINDINGS = _review_contract.DEFAULT_MARKER_BINDINGS
VERDICT_LINE_RE = _review_contract.VERDICT_LINE_RE
WHOLE_DESIGN_LANES = _review_contract.WHOLE_DESIGN_LANES
_COMMENT_KEY_RE = _review_contract._COMMENT_KEY_RE
FINDING_RE = _review_contract.FINDING_RE
DISPOSITION_PREFIX = _review_contract.DISPOSITION_PREFIX
DISPOSITION_MARKER_RE = _review_contract.DISPOSITION_MARKER_RE
SPAN_CLAIM_RE = _review_contract.SPAN_CLAIM_RE
DISPOSITION_BULLET_RE = _review_contract.DISPOSITION_BULLET_RE
span_hash = _review_contract.span_hash
sha_matches = _review_contract.sha_matches
comment_key = _review_contract.comment_key
extract_findings = _review_contract.extract_findings
extract_design_items = _review_contract.extract_design_items
design_lane_verdicts = _review_contract.design_lane_verdicts
design_lane_punchlines = _review_contract.design_lane_punchlines
redact = _review_contract.redact
unanswered_concern_lanes = _review_contract.unanswered_concern_lanes
unanswered_concerns_reason = _review_contract.unanswered_concerns_reason
parse_disposition_record = _review_contract.parse_disposition_record
human_override_actors = _review_contract.human_override_actors


# Strip ANSI escape sequences and C0/C1 control chars from untrusted printed
# text (PR titles / check names are attacker-controllable) to prevent
# terminal/prompt injection into the agent session. The C1 range (\x80-\x9f)
# matters: U+009B is the single-byte CSI, equivalent to ESC-[.
_CTRL_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|[\x00-\x08\x0b-\x1f\x7f-\x9f]")


def sanitize(s):
    return _CTRL_RE.sub("", s or "")


# Explicit state classification (classify every state; fail closed).
PASS_CONCLUSIONS = {"SUCCESS", "NEUTRAL", "SKIPPED"}
# StatusContext (legacy commit statuses) use .state rather than .conclusion.
CTX_PASS = {"SUCCESS"}
CTX_RUNNING = {"PENDING", "EXPECTED"}
DEFAULT_READINESS_CONTEXT = "PR Readiness"

# A host closes an issue on merge ONLY for these verbs. "Related: #n", "Part of
# #n" and a bare "#n" render as links and close nothing, which is how finished
# work merges while its issue stays open forever.
_CLOSING_VERB = r"(?:close[sd]?|fix(?:e[sd])?|resolve[sd]?)"
# A repository slug, in GitHub's own charset. Deliberately narrow so a stray
# path fragment cannot masquerade as a qualified reference.
_REPO_SLUG = r"[A-Za-z0-9][A-Za-z0-9._-]*/[A-Za-z0-9][A-Za-z0-9._-]*"
# The three reference targets the host actually resolves.
_ISSUE_TARGET = (
    r"(?:(?:" + _REPO_SLUG + r")?#\d+" r"|https?://[A-Za-z0-9.-]+/" + _REPO_SLUG + r"/issues/\d+)"
)
_CLOSING_REF = _CLOSING_VERB + r"[ \t]*:?[ \t]+" + _ISSUE_TARGET
# THE ACCEPTED EXPLICIT-TRAILER GRAMMAR, in full:
#
#   trailer := indent? bullet? ref (sep ref)* punct? html-comment?
#   ref     := verb ':'? sp target
#   verb    := close|closes|closed | fix|fixes|fixed | resolve|resolves|resolved
#   target  := '#123' | 'owner/repo#123' | 'https://host/owner/repo/issues/123'
#   sep     := ',' | ';' | 'and'
#
# Two properties are load-bearing.
#
# (1) The trailer must occupy the WHOLE visible line. An unanchored substring
# match also accepted prose that merely MENTIONS a past close -- "Fixed #123 in
# an earlier release; this PR only adds tests." -- and then told the author the
# keyword was fine and the NUMBER was wrong, the one reading that is never true
# for that line. A declaration is a trailer, not a mention. (Trailing
# whitespace, one sentence-ending '.'/';', a CR from a CRLF body, and a trailing
# HTML comment stay accepted, since none of them make the line prose.)
#
# (2) Qualified and URL targets are accepted. The host resolves them, so a body
# carrying one is NOT a body that forgot the verb. No reconciliation against the
# host's own repository identity is needed to accept them here: this classifier
# is only ever reached when the host resolved NOTHING, and the message it
# produces ("the verb is fine, check the reference") is correct whether the
# reference names this repository or another one.
#
# Every regex here runs against the MASKED body from
# ``_visible_markdown_prose``, never the raw one: a fenced block, an indented
# code block, an inline code span and an HTML comment are the surfaces GitHub
# itself does not resolve a closure from, and they are exactly where our own body
# template keeps its worked examples. Matching them would let a copied template
# read as a declaration the author never made.
#
# (3) INDENTATION IS CAPPED AT THREE COLUMNS, and the cap is the load-bearing
# half of that. Four columns is CommonMark's own code boundary, so this single
# bound refuses every code-indented example without the classifier needing to
# know which block type precedes it. Earlier revisions allowed any indent here
# and leaned entirely on the mask to tell code from prose, which required
# tracking whether a paragraph was open -- and that tracker was wrong for an ATX
# heading, a blockquote, a thematic break and a setext underline, each of which
# closes its block so the next indented line IS code. Enumerating block types
# converges on writing a Markdown parser; bounding the indent does not. A tab is
# refused for the same reason (it advances to the four-column stop).
#
# What the cap costs: a trailer indented four or more columns that GitHub WOULD
# resolve as lazy paragraph continuation is not credited as a declaration.
# That is the cheap direction -- it prints an advisory notice on an odd body,
# where the opposite error credits an EXAMPLE and silently suppresses a real
# unrelated-closure warning -- and a trailer is written as a whole line of its
# own, never as indented code.
_CLOSING_KW_RE = re.compile(
    r"^ {0,3}(?:[-*+][ \t]+)?"
    + _CLOSING_REF
    + r"(?:(?:[ \t]*[,;][ \t]*|[ \t]+and[ \t]+)"
    + _CLOSING_REF
    + r")*[ \t]*[.;]?[ \t]*(?:<!--.*?-->[ \t]*)?\r?$",
    re.IGNORECASE | re.MULTILINE,
)
# A resolved closure with no matching explicit trailer may come from prose or a
# manual link in the host UI, so every host-resolved issue number needs human
# confirmation unless the body DECLARES it. Declared numbers are read with the
# same grammar the accept path uses -- find each whole-line trailer with
# ``_CLOSING_KW_RE``, then read every reference on that line -- so one grammar
# governs both directions. Deriving them separately is what would report a
# legitimate trailer (bulleted, qualified ``owner/repo#n``, an issue URL, or
# several references on one line) as missing.
# The slug is CAPTURED, not merely matched: reconciling a host closure against
# a trailer on the number alone lets a stale ``Fixes other/repo#7`` vouch for a
# closure of THIS repository's own #7, which suppresses the very warning this
# function exists to print.
_CLOSING_REF_RE = re.compile(
    _CLOSING_VERB + r"[ \t]*:?[ \t]+"
    r"(?:(?P<slug>" + _REPO_SLUG + r")?#(?P<number>\d+)"
    r"|https?://[A-Za-z0-9.-]+/(?P<url_slug>" + _REPO_SLUG + r")"
    r"/issues/(?P<url_number>\d+))",
    re.IGNORECASE,
)
# Any issue-ish reference at all, to tell "forgot the verb" from
# "genuinely closes nothing". Mirrors the same three targets, so a qualified
# ref or an issue URL written without a verb is reported as a missing keyword
# rather than as a body with no issue link at all.
_BARE_REF_RE = re.compile(
    r"(?<![\w/])(?:" + _REPO_SLUG + r")?#\d+\b"
    r"|https?://[A-Za-z0-9.-]+/" + _REPO_SLUG + r"/issues/\d+\b",
    re.IGNORECASE,
)

# Issue-link classification must see the same Markdown surface GitHub treats as
# prose. Mask ignored contexts character-for-character so MULTILINE anchors and
# word boundaries keep their source positions. Fences allow up to three leading
# spaces; a backtick fence's info string cannot itself contain a backtick.
#
# Markdown's OTHER code block -- four or more columns of indentation -- is NOT
# tracked here, deliberately. Recognising it requires knowing whether a paragraph
# is open, which is a Markdown parser's job: an approximation of that state was
# wrong for an ATX heading, a blockquote, a thematic break and a setext underline,
# each of which closes its block so the next indented line IS code. The bound in
# ``_CLOSING_KW_RE`` covers every one of those shapes without consulting block
# state, so the state machine is not needed and is not here.
_FENCE_OPEN_RE = re.compile(r"^ {0,3}(?P<fence>`{3,}|~{3,})(?P<info>.*)$")


def _fence_opening(line):
    match = _FENCE_OPEN_RE.match(line)
    if not match:
        return None
    fence = match.group("fence")
    if fence[0] == "`" and "`" in match.group("info"):
        return None
    return fence[0], len(fence)


def _is_closing_fence(line, fence_char, opening_length):
    candidate = line[:-1] if line.endswith("\r") else line
    indent = 0
    while indent < len(candidate) and candidate[indent] == " ":
        indent += 1
    if indent > 3:
        return False
    end = indent
    while end < len(candidate) and candidate[end] == fence_char:
        end += 1
    return end - indent >= opening_length and not candidate[end:].strip(" \t")


def _mask_html_comments(line, in_comment):
    masked = list(line)
    cursor = 0
    if in_comment:
        comment_end = line.find("-->")
        if comment_end < 0:
            return " " * len(line), True
        cursor = comment_end + 3
        masked[:cursor] = " " * cursor

    while True:
        comment_start = line.find("<!--", cursor)
        if comment_start < 0:
            return "".join(masked), False
        comment_end = line.find("-->", comment_start + 4)
        if comment_end < 0:
            masked[comment_start:] = " " * (len(line) - comment_start)
            return "".join(masked), True
        cursor = comment_end + 3
        masked[comment_start:cursor] = " " * (cursor - comment_start)


def _mask_inline_code(text):
    runs = []
    cursor = 0
    while cursor < len(text):
        start = text.find("`", cursor)
        if start < 0:
            break
        end = start + 1
        while end < len(text) and text[end] == "`":
            end += 1
        runs.append((start, end))
        cursor = end

    next_equal: list[int | None] = [None] * len(runs)
    next_by_length: dict[int, int] = {}
    for index in range(len(runs) - 1, -1, -1):
        run_length = runs[index][1] - runs[index][0]
        next_equal[index] = next_by_length.get(run_length)
        next_by_length[run_length] = index

    masked = list(text)
    index = 0
    while index < len(runs):
        closing_index = next_equal[index]
        if closing_index is None:
            index += 1
            continue
        start = runs[index][0]
        end = runs[closing_index][1]
        for offset in range(start, end):
            if masked[offset] not in "\r\n":
                masked[offset] = " "
        index = closing_index + 1
    return "".join(masked)


def _visible_markdown_prose(body):
    """Mask fenced/code-span/comment examples while preserving line offsets."""
    body = body or ""
    visible_lines = []
    fence_char = None
    fence_length = 0
    in_comment = False

    for line in body.split("\n"):
        if fence_char is not None:
            if _is_closing_fence(line, fence_char, fence_length):
                fence_char = None
                fence_length = 0
            visible_lines.append(" " * len(line))
            continue

        # A real fence opener wins over comment-looking text in its info
        # string. While inside a comment, masking happens first so a fence-like
        # example cannot alter fence state.
        opening = None if in_comment else _fence_opening(line)
        if opening is not None:
            fence_char, fence_length = opening
            visible_lines.append(" " * len(line))
            continue

        masked_line, in_comment = _mask_html_comments(line, in_comment)
        opening = None if in_comment else _fence_opening(masked_line)
        if opening is not None:
            fence_char, fence_length = opening
            visible_lines.append(" " * len(line))
            continue
        visible_lines.append(masked_line)

    return _mask_inline_code("\n".join(visible_lines))


# GitHub exposes ``Issue.number`` as a positive GraphQL Int. Normalize the
# host value and trailer text without converting untrusted digit strings to a
# Python int: Python 3.10 accepts arbitrarily long strings while 3.11+ raises,
# and readiness must behave identically on every supported interpreter.
_GITHUB_ISSUE_NUMBER_MAX = 2_147_483_647
_GITHUB_ISSUE_NUMBER_MAX_TEXT = "2147483647"


def _normalize_issue_number(value):
    """Return canonical decimal text for a GitHub issue number, else None."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        if not 0 < value <= _GITHUB_ISSUE_NUMBER_MAX:
            return None
        return str(value)
    if (
        not isinstance(value, str)
        or not value
        or not value.isascii()
        or not value.isdigit()
        or len(value) > len(_GITHUB_ISSUE_NUMBER_MAX_TEXT)
    ):
        return None
    normalized = value.lstrip("0")
    if not normalized:
        return None
    if (
        len(normalized) == len(_GITHUB_ISSUE_NUMBER_MAX_TEXT)
        and normalized > _GITHUB_ISSUE_NUMBER_MAX_TEXT
    ):
        return None
    return normalized


def _issue_number_sort_key(number):
    return (len(number), number)


def _normalize_repo_key(value):
    """Return canonical case-folded ``owner/repo`` text, else None.

    ``owner/repo`` is a GitHub API slug, NOT a filesystem path: the ``/`` is the
    API's own literal separator, so ``os.path.join`` would be wrong here (it
    emits a backslash on Windows). Built with ``format`` rather than ``+`` so
    the portability scanner's path-assembly rule does not read it as one.

    GitHub owner and repository names are case-insensitive, so the comparison
    must be too: otherwise ``Fixes KiroDotDev/KiroCrew#7`` would read as naming
    a different repository from the host's own ``kirodotdev/KiroCrew`` and the
    trailer would stop covering the closure it plainly declares.
    """
    if not isinstance(value, str):
        return None
    owner, _, name = value.partition("/")
    if not owner or not name or "/" in name:
        return None
    return "{}/{}".format(owner.lower(), name.lower())


def _host_ref_repo_key(ref):
    """Return the case-folded ``owner/repo`` a host closing reference names."""
    if not isinstance(ref, dict):
        return None
    repository = ref.get("repository")
    if not isinstance(repository, dict):
        return None
    owner = repository.get("owner")
    login = owner.get("login") if isinstance(owner, dict) else None
    name = repository.get("name")
    if not isinstance(login, str) or not isinstance(name, str):
        return None
    return _normalize_repo_key("{}/{}".format(login, name))


def _undeclared_closing_numbers(declared, closing_refs):
    """Return (resolved numbers, numbers the body does not declare, well_formed).

    Accounting is per REPOSITORY, not per number, and the asymmetry between the
    two kinds of declaration is the whole point:

    * A QUALIFIED declaration (``Fixes owner/repo#7``, an issue URL, or a bare
      ``#7`` when the caller supplied the PR's own repository) covers every host
      reference naming that same repository.
    * A WILDCARD declaration -- a bare ``#7`` whose repository cannot be
      resolved because the caller passed none -- covers exactly ONE reference.
      One unqualified trailer cannot honestly vouch for two closures of the same
      number in two different repositories, so the second is reported.

    A host reference carrying no ``repository`` object is covered by any
    declaration of its number: nothing there can be reconciled in either
    direction, and inventing a mismatch would fire this advisory on a body that
    is fine.

    Deliberately absent: a "the same number resolved twice" notice. An earlier
    revision had one, and once matching became repository-aware it fired on a
    fully correct body -- ``Fixes #7`` plus ``Fixes other/repo#7`` with both
    closures resolved and both matched. Genuine ambiguity is already the
    undeclared case above, so the branch was redundant as well as wrong.
    """
    known: dict = {}
    wildcards: dict = {}
    for repo_key, number in declared:
        if repo_key is None:
            wildcards[number] = wildcards.get(number, 0) + 1
        else:
            known.setdefault(number, set()).add(repo_key)

    numbers = []
    undeclared = set()
    well_formed = True
    for ref in closing_refs:
        try:
            value = ref["number"]
        except (KeyError, TypeError):
            well_formed = False
            continue
        number = _normalize_issue_number(value)
        if number is None:
            well_formed = False
            continue
        numbers.append(number)
        host_repo = _host_ref_repo_key(ref)
        if host_repo is not None and host_repo in known.get(number, ()):
            continue
        if wildcards.get(number):
            wildcards[number] -= 1
            continue
        if host_repo is None and known.get(number):
            continue
        undeclared.add(number)
    return numbers, undeclared, well_formed


def _declared_closing_numbers(visible_body, base_repo=None):
    """Return (declared ``(repo_key, number)`` pairs, well_formed).

    ``repo_key`` is the case-folded ``owner/repo`` the trailer names explicitly,
    else *base_repo* for an unqualified ``#<n>`` (which can only mean the PR's
    own repository), else ``None`` when neither is known.

    ``well_formed`` is False when a trailer names a number the host could never
    have issued (out of GitHub's positive-Int32 range, or all zeros), which is
    reported rather than silently dropped: a body that declares a closure we
    cannot line up against the host's answer still needs a human to confirm the
    closures that DID resolve are the intended ones.
    """
    base_key = _normalize_repo_key(base_repo)
    declared = set()
    well_formed = True
    for line in _CLOSING_KW_RE.finditer(visible_body):
        for ref in _CLOSING_REF_RE.finditer(line.group(0)):
            number = _normalize_issue_number(ref.group("number") or ref.group("url_number"))
            if number is None:
                well_formed = False
                continue
            slug = ref.group("slug") or ref.group("url_slug")
            declared.add((_normalize_repo_key(slug) or base_key, number))
    return declared, well_formed


# The DECLARATION grammar: what a PR body says it is for. A declaration is a
# closing verb (the host auto-closes the issue on merge) OR a non-closing
# ``Refs`` / ``Part of`` (the issue stays open: partial work, a follow-up of
# several), each followed by one of the three issue targets. It STARTS a
# visible line (three columns of indent at most, an optional bullet) and what
# follows the reference on that line is free. Everything ``_CLOSING_KW_RE``
# refuses for being code or quotation -- four-column indent, a ``>``
# blockquote, a mid-sentence mention -- this refuses too, since none of them
# can start a line this way; what it accepts that ``_CLOSING_KW_RE`` does not
# is a trailer followed by prose (``Fixes #7 (the Windows half)``) and the
# non-closing verbs, which GitHub renders as links and never resolves as a
# closure -- the NOTICE path has no use for them, a gate that asks "which issue
# is this work for" does. Every verb is read at a word start: the line-start
# regex consumes the bullet/indent for the first one, and the lookbehind in
# ``_DECLARING_REF_RE`` guards the rest of the line, so ``unresolved: #2`` in
# the free tail is not ``resolved #2``.
_DECLARING_VERB = r"(?:" + _CLOSING_VERB[3:-1] + r"|refs?|part of)"
_DECLARING_LINE_START_RE = re.compile(
    r"^ {0,3}(?:[-*+][ \t]+)?(?=" + _DECLARING_VERB + r"[ \t]*:?[ \t]+)",
    re.IGNORECASE | re.MULTILINE,
)
# A URL target counts only on the github.com host: GitHub renders nothing from
# ``https://example.com/.../issues/N`` and a gate that credited it would be
# crediting a link to nowhere. (``_ISSUE_TARGET`` for the NOTICE path keeps
# any host, because that classifier only explains a body the host already
# resolved to nothing and its message is right either way.)
_DECLARING_REF_RE = re.compile(
    r"(?<![A-Za-z0-9_])" + _DECLARING_VERB + r"[ \t]*:?[ \t]+"
    r"(?:(?P<slug>" + _REPO_SLUG + r")?#(?P<number>\d+)"
    r"|https?://(?:www\.)?github\.com/(?P<url_slug>" + _REPO_SLUG + r")"
    r"/issues/(?P<url_number>\d+))",
    re.IGNORECASE,
)


def declared_issue_numbers(body, repo):
    """Return (numbers declared for ``repo``, well_formed) -- the public grammar.

    The ONE entry point other surfaces use to read which issues a PR body
    declares it is for (`.github/scripts/issue_gate_refs.py`, the Issue Gate's
    adapter, is its caller), so the masking and the reference grammar are never
    re-derived elsewhere: a semantic change here reaches every caller, where a
    caller rewrapping a private pattern drifts from it unnoticed.

    ``body`` is masked with ``_visible_markdown_prose`` first, then read with
    ``_DECLARING_LINE_START_RE`` / ``_DECLARING_REF_RE`` (stated above): a
    declaration starts a line and the rest of that line is free, every reference
    on it is read. A closing verb and a non-closing ``Refs`` / ``Part of`` both
    declare; only the former closes on merge. This is a different question from
    the one ``closing_link_reason`` answers (why the HOST resolved no closure),
    which keeps its own whole-line, closing-verbs-only classifier.

    Only references naming ``repo`` are returned (an unqualified ``#<n>`` can
    only mean the PR's own repository). ``well_formed`` is False when a
    reference names a number the host could never have issued, which the
    caller reports rather than drops. Numbers are canonical decimal strings,
    sorted numerically.
    """
    visible = _visible_markdown_prose(body)
    repo_key = _normalize_repo_key(repo)
    numbers = set()
    well_formed = True
    for start in _DECLARING_LINE_START_RE.finditer(visible):
        line_end = visible.find("\n", start.end())
        line = visible[start.end() : line_end if line_end >= 0 else len(visible)]
        for ref in _DECLARING_REF_RE.finditer(line):
            number = _normalize_issue_number(ref.group("number") or ref.group("url_number"))
            if number is None:
                well_formed = False
                continue
            slug = ref.group("slug") or ref.group("url_slug")
            if (_normalize_repo_key(slug) or repo_key) == repo_key:
                numbers.add(number)
    return sorted(numbers, key=_issue_number_sort_key), well_formed


def closing_link_reason(body, closing_refs, repo=None):
    """Return an advisory issue-link reason, else None.

    ADVISORY ONLY — the caller prints this, it never changes the exit code. An
    issue-less PR is legitimate, and a green PR should not be held on
    bookkeeping.

    ``closing_refs`` is the host's OWN resolution of the body (the
    ``closingIssuesReferences`` field), so it is the truth about what will
    actually close. The body regexes classify *why* it resolved to nothing --
    which is what makes the message actionable -- and, when it DID resolve
    something, whether every resolved issue is backed by an explicit trailer or
    whether a closure needs human confirmation. The accepted explicit-trailer
    grammar is stated in full above ``_CLOSING_KW_RE``: a whole visible line
    carrying one or more ``<verb> <target>`` references, where a target may be
    ``#123``, ``owner/repo#123`` or an issue URL.

    ``repo`` is the viewed PR's own ``owner/name`` when the caller knows it. It
    is what an unqualified ``#<n>`` trailer resolves to, so supplying it lets a
    resolved closure be matched by REPOSITORY AND NUMBER rather than by number
    alone. Optional, and omitting it only widens the match.
    """
    body = body or ""
    visible_body = _visible_markdown_prose(body)
    if closing_refs:
        declared, trailers_well_formed = _declared_closing_numbers(visible_body, repo)
        _resolved, missing_numbers, refs_well_formed = _undeclared_closing_numbers(
            declared, closing_refs
        )
        if refs_well_formed and trailers_well_formed and not missing_numbers:
            return None
        if not trailers_well_formed:
            return (
                "body has a malformed explicit closing trailer "
                "(confirm every closure is intentional; use one valid "
                "'Fixes #<n>' trailer per issue)"
            )
        if not refs_well_formed:
            return (
                "host returned a malformed closing issue reference "
                "(confirm every closure is intentional)"
            )
        missing_text = (
            " matching "
            + ", ".join(
                "#{}".format(number)
                for number in sorted(missing_numbers, key=_issue_number_sort_key)
            )
            if missing_numbers
            else " matching every host-resolved closure"
        )
        return (
            "host will close an issue but the body has no explicit closing trailer"
            + missing_text
            + " (confirm every closure is intentional; add one 'Fixes #<n>' "
            "trailer per issue)"
        )
    if _CLOSING_KW_RE.search(visible_body):
        # A visible verb is present but the host resolved nothing: the number,
        # repository target, or issue state does not form a live closure. A code
        # fence is not a candidate explanation -- fenced text is masked
        # before this runs, so it cannot reach here in the first place.
        return (
            "body has a closing keyword but the host resolved no issue "
            "(check the number, repository, and issue state)"
        )
    if _BARE_REF_RE.search(visible_body):
        return (
            "body references an issue with no closing keyword - use "
            "'Fixes #<n>' so it closes on merge (the Issue Gate lane also accepts "
            "'Part of #<n>' for partial work)"
        )
    return (
        "no issue link - add 'Fixes #<n>' (or 'Part of #<n>') for a triaged issue; "
        "the Issue Gate lane fails the PR without one once it is enabled"
    )


# Page cap so a pathological PR can't make us loop unbounded (100 * 50 = 5000).
_MAX_THREAD_PAGES = 50
_MAX_COMMENT_PAGES = 50

FINDING_LINE_RE = re.compile(r"^\s*FINDING\b", re.MULTILINE)

# Any revision a lane's stampless notice names. Every such notice writes the head
# it declined to review into its own prose, and that is what scopes the notice's
# exemption to one revision instead of standing forever.
BODY_SHA_RE = re.compile(r"\b[0-9a-f]{7,40}\b")


def fetch_disposition_comments(repo, number):
    return _review_contract.fetch_disposition_comments(repo, number, run)


def author_write_verdict(repo, login):
    return _review_contract.author_write_verdict(repo, login, run)


def author_is_repo_writer(repo, login):
    return _review_contract.author_is_repo_writer(repo, login, run)


def writer_disposition_records(repo, comments):
    return _review_contract.writer_disposition_records(repo, comments, run, author_write_verdict)


disposition_violations = _review_contract.disposition_violations
superseded_verdicts = _review_contract.superseded_verdicts


def resolve_marker_bindings(argv, environ):
    """Resolve the comment-key -> reviewer-name bindings (flag > env > default)."""
    raw = None
    for i, a in enumerate(argv):
        if a == "--marker-bindings" and i + 1 < len(argv):
            raw = argv[i + 1]
        elif a.startswith("--marker-bindings="):
            raw = a.split("=", 1)[1]
    if raw is None:
        raw = environ.get("PREPARE_PR_MARKER_BINDINGS")
    if not raw:
        return dict(DEFAULT_MARKER_BINDINGS)
    out = {}
    for pair in raw.split(","):
        if "=" in pair:
            k, _, v = pair.partition("=")
            if k.strip() and v.strip():
                out[k.strip()] = v.strip().upper()
    return out or dict(DEFAULT_MARKER_BINDINGS)


def resolve_marker_authors(argv, environ):
    """Resolve the comment-author allowlist for marker evaluation.

    Precedence mirrors the other seams: ``--marker-authors`` CLI flag >
    ``PREPARE_PR_MARKER_AUTHORS`` env var > DEFAULT_MARKER_AUTHORS. Logins are
    compared case-insensitively.
    """
    raw = None
    for i, a in enumerate(argv):
        if a == "--marker-authors" and i + 1 < len(argv):
            raw = argv[i + 1]
        elif a.startswith("--marker-authors="):
            raw = a.split("=", 1)[1]
    if raw is None:
        raw = environ.get("PREPARE_PR_MARKER_AUTHORS")
    if not raw:
        return {a.lower() for a in DEFAULT_MARKER_AUTHORS}
    return {n.strip().lower() for n in raw.split(",") if n.strip()} or {
        a.lower() for a in DEFAULT_MARKER_AUTHORS
    }


def resolve_readiness_context(argv, environ):
    """Resolve the aggregate-readiness status-context name.

    Precedence: ``--readiness-context`` CLI flag > ``PREPARE_PR_READINESS_CONTEXT``
    env var > the Kiro Crew default. Lets a project profile name a non-default
    aggregate status; when unset, behavior is identical to before (the default
    context, with the full-rollup fallback when that context is absent).
    """
    for i, a in enumerate(argv):
        if a == "--readiness-context" and i + 1 < len(argv):
            return argv[i + 1]
        if a.startswith("--readiness-context="):
            return a.split("=", 1)[1]
    env = environ.get("PREPARE_PR_READINESS_CONTEXT")
    return env if env else DEFAULT_READINESS_CONTEXT


def resolve_reviewers(argv, environ):
    """Resolve an optional reviewer-name filter for marker evaluation.

    Precedence mirrors ``resolve_readiness_context``: ``--reviewers`` CLI flag >
    ``PREPARE_PR_REVIEWERS`` env var > None (discovery mode). Discovery mode
    evaluates every ``[<NAME>-REVIEWED]`` stamp found, which self-configures on
    any repo whose reviewers emit the stamp contract. Naming reviewers both
    scopes freshness to those names AND requires each to have a fresh stamp --
    a pinned reviewer that never posted reads as stale, so an emitter drift or
    a bot that fails to post cannot make the gate silently vacuous.
    """
    raw = None
    for i, a in enumerate(argv):
        if a == "--reviewers" and i + 1 < len(argv):
            raw = argv[i + 1]
        elif a.startswith("--reviewers="):
            raw = a.split("=", 1)[1]
    if raw is None:
        raw = environ.get("PREPARE_PR_REVIEWERS")
    if not raw:
        return None
    names = {n.strip().upper() for n in raw.split(",") if n.strip()}
    return names or None


def head_run_check_enabled(argv, environ):
    """Whether the pull_request-run-for-head assertion is enabled.

    ``--head-run-check=off`` / ``PREPARE_PR_HEAD_RUN_CHECK=off`` disable it --
    the escape hatch for a repo shape the event heuristic misreads, degrading
    that one gate to pre-existing behavior instead of a permanent block. Any
    other value (or unset) keeps it on.
    """
    val = None
    for i, a in enumerate(argv):
        if a == "--head-run-check" and i + 1 < len(argv):
            val = argv[i + 1]
        elif a.startswith("--head-run-check="):
            val = a.split("=", 1)[1]
    if val is None:
        val = environ.get("PREPARE_PR_HEAD_RUN_CHECK")
    return (val or "").strip().lower() not in ("off", "0", "false", "no")


_VALUE_FLAGS = (
    "--readiness-context",
    "--reviewers",
    "--head-run-check",
    "--marker-authors",
    "--marker-bindings",
)

# Flags that take NO value. positional_args must drop these too: a bare
# --json left in the positional list is read as the PR number, which silently
# resolves the wrong PR (or fails env-check) instead of erroring.
_BOOL_FLAGS = ("--json",)


def positional_args(argv):
    """Return argv with the flags (and any values they take) removed."""
    out = []
    skip = False
    for a in argv:
        if skip:
            skip = False
            continue
        if a in _BOOL_FLAGS:
            continue
        if a in _VALUE_FLAGS:
            skip = True
            continue
        if a.startswith(tuple(f + "=" for f in _VALUE_FLAGS)):
            continue
        out.append(a)
    return out


def run(args):
    try:
        p = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace")
        return p.returncode, p.stdout.strip(), p.stderr.strip()
    except OSError as exc:
        return 127, "", "{}: {}".format(args[0], exc)


def err(msg):
    sys.stderr.write(msg + "\n")


# statusCheckRollup needs Checks read access, which a fine-grained PAT
# structurally cannot grant, and gh resolves every field of one --json request
# atomically -- so bundling the rollup with the core fields makes the WHOLE
# read fail for those tokens. The rollup is therefore fetched in its own call
# (fetch_check_rollup) and degrades softly: the caller keeps the core metadata
# and reports CI as unknown instead of aborting. The second read re-fetches
# headRefOid and is discarded on a mismatch with the core read's head, so a
# push landing between the two reads can never pair one head's metadata with
# another head's checks. The parity-pinned copy in pr_findings.py keeps each
# command's check-rollup path explicit.
#
# That own call is GraphQL rather than `gh pr view --json statusCheckRollup`:
# the rows gh returns carry the workflow's display NAME and nothing else about
# the run (measured: __typename completedAt conclusion context detailsUrl name
# startedAt state status targetUrl workflowName), and collapse_superseded keys
# on the run itself -- its id, its triggering event, its workflow definition's
# id and its own conclusion -- all reached through the check suite. Nothing in
# the --json field set exposes them, so there is no selection to extend there.
ROLLUP_UNAVAILABLE_NOTICE = (
    "CI check status UNAVAILABLE - the statusCheckRollup fetch failed (a token "
    "without Checks read access, e.g. any fine-grained PAT, cannot fetch it); "
    "treat CI as UNKNOWN, not as 'no checks yet'"
)
ROLLUP_HEAD_MOVED_NOTICE = (
    "CI check status DISCARDED - the PR head changed between the core read and "
    "the rollup read (concurrent push); treat CI as UNKNOWN and re-run for a "
    "consistent snapshot"
)
# Owner, repository, number and cursor travel as GraphQL variables; the document
# is fixed text. The three strings go through gh's `-f` (raw string): `-F` is
# the TYPED form and turns an all-digit value into a JSON integer, which the
# host then rejects against `String!`, so an owner or repository named `2048`
# would read as UNAVAILABLE forever. Only `n` is `-F`, because `Int!` needs it.
# Both ids are nullable Int on the wire (an app-created check run has a
# checkSuite but no workflowRun); event, status and conclusion are what the
# collapse and classify_check read.
ROLLUP_QUERY = (
    "query($o:String!,$r:String!,$n:Int!,$c:String){repository(owner:$o,name:$r)"
    "{pullRequest(number:$n){headRefOid commits(last:1){nodes{commit{oid "
    "statusCheckRollup{contexts(first:100,after:$c){pageInfo{hasNextPage endCursor} "
    "nodes{__typename ... on CheckRun{name status conclusion startedAt detailsUrl "
    "checkSuite{conclusion workflowRun{databaseId event workflow{databaseId name}}}} "
    "... on StatusContext{context state targetUrl}}}}}}}}}}"
)
# A board past this many pages reads UNKNOWN rather than in part: a partial read
# could keep a displaced row whose successor sits on the page never fetched.
_MAX_ROLLUP_PAGES = 10


def _host_id(value):
    """``value`` when it can serve as a host-supplied id, else None.

    bool is refused because it is an int subclass and would group rows under True.
    """
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value


def flatten_rollup_row(node):
    """One rollup node in the flat shape the rest of this file reads, or None.

    A CheckRun's run fields are lifted out of its check suite and travel beside
    the row's own: ``workflowName`` (the display label the report prints),
    ``workflowRunId``, ``workflowRunEvent``, ``workflowDefinitionId`` and
    ``workflowRunConclusion``. The suite's conclusion IS the run's: WorkflowRun
    exposes none of its own, and CheckSuite.workflowRun is the inverse edge of
    the one followed here. A field the host withheld is left absent rather than
    defaulted, so a missing id reads as "unidentified" downstream and never as
    a shared key. A StatusContext passes through untouched. None for anything
    that is not a well-formed node, so the caller can refuse the whole page.
    """
    if not isinstance(node, dict) or not isinstance(node.get("__typename"), str):
        return None
    row = {k: v for k, v in node.items() if k != "checkSuite"}
    if node["__typename"] != "CheckRun":
        return row
    suite = node.get("checkSuite")
    run = suite.get("workflowRun") if isinstance(suite, dict) else None
    workflow = run.get("workflow") if isinstance(run, dict) else None
    name = workflow.get("name") if isinstance(workflow, dict) else None
    if isinstance(name, str):
        row["workflowName"] = name
    if isinstance(run, dict):
        if _host_id(run.get("databaseId")) is not None:
            row["workflowRunId"] = run["databaseId"]
        if isinstance(run.get("event"), str) and run["event"]:
            row["workflowRunEvent"] = run["event"]
    if isinstance(workflow, dict) and _host_id(workflow.get("databaseId")) is not None:
        row["workflowDefinitionId"] = workflow["databaseId"]
    if isinstance(suite, dict) and isinstance(suite.get("conclusion"), str) and suite["conclusion"]:
        row["workflowRunConclusion"] = suite["conclusion"]
    return row


def fetch_check_rollup(repo, number, expected_head):
    """Return (rollup rows, notice); the notice is non-empty when degraded.

    Pages through the head commit's statusCheckRollup. Every page re-reads the
    pull request's head AND names the commit the rollup hangs off; either
    disagreeing with ``expected_head`` discards the whole read, so a push that
    lands mid-pagination can never pair one head's metadata with another's
    checks. Any failed or malformed page, or a board past the page cap, reads
    UNAVAILABLE: rows so far are dropped, never reported as the board.
    """
    if "/" not in (repo or "") or not number:
        return [], ROLLUP_UNAVAILABLE_NOTICE
    owner, name = repo.split("/", 1)
    rows: list[dict] = []
    cursor = None
    for _ in range(_MAX_ROLLUP_PAGES):
        args = ["gh", "api", "graphql", "-f", "query=" + ROLLUP_QUERY]
        if cursor:
            args += ["-f", "c=" + cursor]
        args += ["-f", "o=" + owner, "-f", "r=" + name, "-F", "n=" + str(number)]
        rc, out, _ = run(args)
        if rc != 0 or not out.strip():
            return [], ROLLUP_UNAVAILABLE_NOTICE
        try:
            pr = json.loads(out)["data"]["repository"]["pullRequest"]
            head = (pr.get("headRefOid") or "").strip()
            commits = pr["commits"]["nodes"]
            commit = commits[0]["commit"] if commits else None
        except (ValueError, KeyError, TypeError, AttributeError, IndexError):
            return [], ROLLUP_UNAVAILABLE_NOTICE
        if expected_head and head != expected_head:
            return [], ROLLUP_HEAD_MOVED_NOTICE
        if commit is None:
            return [], ""  # a pull request with no commit has no checks
        if not isinstance(commit, dict) or not isinstance(commit.get("oid"), str):
            return [], ROLLUP_UNAVAILABLE_NOTICE
        if expected_head and commit["oid"] != expected_head:
            return [], ROLLUP_HEAD_MOVED_NOTICE
        rollup = commit.get("statusCheckRollup")
        if rollup is None:
            return rows, ""  # the host reports no checks for this head
        try:
            contexts = rollup["contexts"]
            nodes = contexts["nodes"]
            page = contexts["pageInfo"] or {}
            flat = [flatten_rollup_row(n) for n in nodes]
        except (KeyError, TypeError):
            return [], ROLLUP_UNAVAILABLE_NOTICE
        if any(r is None for r in flat):
            return [], ROLLUP_UNAVAILABLE_NOTICE
        rows.extend(flat)
        if not page.get("hasNextPage"):
            return rows, ""
        cursor = page.get("endCursor")
        if not isinstance(cursor, str) or not cursor:
            return [], ROLLUP_UNAVAILABLE_NOTICE
    return [], ROLLUP_UNAVAILABLE_NOTICE  # page cap with pages left: UNKNOWN, never partial


def classify_check(entry):
    """Return 'pass' | 'running' | 'fail' for one statusCheckRollup entry.

    Fail-closed: any unrecognized COMPLETED conclusion or unknown shape counts
    as 'fail' rather than silently passing.
    """
    status = (entry.get("status") or "").upper()
    conclusion = (entry.get("conclusion") or "").upper()
    state = (entry.get("state") or "").upper()
    if status:  # CheckRun
        if status != "COMPLETED":
            return "running"  # queued/in-progress/any non-terminal state
        return "pass" if conclusion in PASS_CONCLUSIONS else "fail"
    if state:  # StatusContext
        if state in CTX_PASS:
            return "pass"
        if state in CTX_RUNNING:
            return "running"
        return "fail"
    return "fail"  # unknown shape -> fail closed


def failing_check_identity(entry):
    """Workflow-qualified label for a failing check, for ``progress_key``.

    Follows ``collapse_superseded()``'s identity axis -- a StatusContext is
    keyed by its context name, a CheckRun by (workflow, name) -- because a
    display name alone is not an identity: two workflows can publish the same
    check name. If one workflow's copy starts failing while the other's stops,
    a name-only list is byte-identical across that change, and a stall streak
    would run straight through a PR whose blocking check actually moved. The
    workflow is named by its display label here, not its definition id: this
    string is read by a person in the report as well as compared by the loop.
    """
    context = entry.get("context")
    if context:
        return sanitize(context)
    workflow = sanitize(entry.get("workflowName") or "")
    name = sanitize(entry.get("name") or "check")
    return "{} / {}".format(workflow, name) if workflow else name


def superseded_key(entry):
    """The identity a CheckRun row can be superseded within, or None to exempt it.

    The workflow DEFINITION's id, the run's triggering EVENT and the check name.
    Never the workflow's display name: a host permits two workflow files to carry
    one ``name:``, and each may publish a check of the same name, so a label would
    group two independent workflows and the collapse would drop one of them. The
    event is in it because one file can declare several triggers, and a file on
    ``push`` and ``pull_request`` produces two runs of itself on one commit --
    concurrent dispatches rather than an attempt and its replacement, so only a
    later run of the SAME trigger may replace an earlier one.

    None whenever the host did not supply a component, as for a check run an app
    created outside Actions (a checkSuite with no workflowRun). Grouping such rows
    under a missing key would put every one of them into one identity and drop
    all but the newest; the only thing left to key on would be the display name,
    which is what this refuses.
    """
    name = entry.get("name")
    if not isinstance(name, str) or not name:
        return None
    definition = _host_id(entry.get("workflowDefinitionId"))
    if definition is None:
        return None
    event = entry.get("workflowRunEvent")
    if not isinstance(event, str) or not event:
        return None
    return (definition, event, name)


def _displaced(entry):
    """Whether removing this row of an OLDER run takes no verdict with it.

    The rollup carries no lineage edge: a greater run id proves only that a run
    started later, and a later run of one identity can be an independent dispatch
    (``synchronize`` and ``edited`` are both ``pull_request``), so recency alone
    never licenses dropping a row. A run the concurrency group CANCELLED in favour
    of its successor is the one displacement the rollup does establish, and it is
    a property of the RUN, read from the run: a row reaches CANCELLED inside live
    runs too -- fail-fast cancelling a matrix job's siblings, a job cancelled
    because something in its ``needs`` failed, an operator cancelling one job --
    and in each the run concluded FAILURE. The row's own COMPLETED+CANCELLED is
    required as well, because a cancelled run can still hold a row that reached a
    real FAILURE before the cancel landed.
    """
    if entry.get("workflowRunConclusion") != "CANCELLED":
        return False
    status = (entry.get("status") or "").upper()
    conclusion = (entry.get("conclusion") or "").upper()
    return status == "COMPLETED" and conclusion == "CANCELLED"


def collapse_superseded(rollup):
    """Drop the check rows a newer run of the same check has displaced.

    A host keeps a replaced round's rows in the rollup beside the round that
    replaced them, so counting every row inflates the failure count with
    attempts that are not live. This is the rule the structured monitor's GitHub
    provider enforces (``_mark_superseded_rows``), applied by removal:

    * Identity is ``superseded_key``: workflow definition, run event, check name.
    * Newest is the greatest RUN id, which increases monotonically. Not the row's
      ``startedAt`` -- that is when a JOB got a runner, and a busy queue starts an
      older run's job after a newer run's.
    * A row is removed only when it belongs to an older run than the newest of
      its identity AND ``_displaced`` holds. A replaced round's FAILURE rows stay;
      a cancelled row inside a live run stays; a cancelled NEWEST run stays, since
      dropping it would revive the verdict it superseded.
    * Two rows of ONE run never displace each other: a workflow can publish a
      check run under its own job's display name, so both are live.
    * A row without a key or a run id is exempt and takes no part in choosing the
      newest run, since it may BE the run that would supersede the others.
    * A StatusContext is never collapsed. The host reports one status per
      context, the latest, so there is nothing to order; the provider keeps every
      status row too, and a rule here would be a second place to be wrong.

    Input order is preserved. When in doubt, over-report rather than hide a
    live failure.
    """
    newest_run: dict[tuple, int] = {}
    for e in rollup:
        if e.get("context"):
            continue
        key = superseded_key(e)
        run_id = _host_id(e.get("workflowRunId"))
        if key is None or run_id is None:
            continue
        if key not in newest_run or run_id > newest_run[key]:
            newest_run[key] = run_id
    kept = []
    for e in rollup:
        if e.get("context"):
            kept.append(e)
            continue
        key = superseded_key(e)
        run_id = _host_id(e.get("workflowRunId"))
        if key is None or run_id is None or run_id == newest_run[key]:
            kept.append(e)
            continue
        if not _displaced(e):
            kept.append(e)
    return kept


def unresolved_thread_count(number):
    """Count unresolved review threads across all pages for advisory output."""
    rc, repo, _ = run(["gh", "repo", "view", "--json", "nameWithOwner", "-q", ".nameWithOwner"])
    if rc != 0 or "/" not in repo:
        return None
    owner, name = repo.split("/", 1)
    query = (
        "query($o:String!,$r:String!,$n:Int!,$c:String){repository(owner:$o,"
        "name:$r){pullRequest(number:$n){reviewThreads(first:100,after:$c)"
        "{pageInfo{hasNextPage endCursor} nodes{isResolved}}}}}"
    )
    cursor = None
    count = 0
    for _ in range(_MAX_THREAD_PAGES):
        args = [
            "gh",
            "api",
            "graphql",
            "-f",
            "query=" + query,
            "-F",
            "o=" + owner,
            "-F",
            "r=" + name,
            "-F",
            "n=" + str(number),
        ]
        if cursor:
            args += ["-F", "c=" + cursor]
        rc, out, _ = run(args)
        if rc != 0 or not out:
            return None
        try:
            rt = json.loads(out)["data"]["repository"]["pullRequest"]["reviewThreads"]
        except (ValueError, KeyError, TypeError):
            return None
        count += sum(1 for t in (rt.get("nodes") or []) if not t.get("isResolved", False))
        page = rt.get("pageInfo") or {}
        if not page.get("hasNextPage") or not page.get("endCursor"):
            return count
        cursor = page["endCursor"]
    return None  # hit the page cap with more pages left -> uncertain (fail-closed)


def detect_repo(pr_url=""):
    """Return "owner/name" for the VIEWED PR, or "" when undetectable.

    Prefers the PR's own URL: the positional argument may be a full PR URL for
    a different repository than the cwd's checkout, and querying the checkout's
    repo for that PR's comments/runs would silently evaluate the wrong data
    (markers invisible, gates vacuous). Falls back to the cwd's repo only when
    no URL is available.
    """
    m = re.match(r"https?://[^/]+/([^/]+)/([^/]+)/pull/\d+", pr_url or "")
    if m:
        return "{}/{}".format(m.group(1), m.group(2))
    rc, repo, _ = run(["gh", "repo", "view", "--json", "nameWithOwner", "-q", ".nameWithOwner"])
    return repo.strip() if rc == 0 and "/" in repo else ""


def fetch_issue_comments(repo, number, keep=None, run_command=None):
    return _review_contract.fetch_issue_comments(repo, number, run_command or run, keep=keep)


def is_trusted_bot_comment(c, trusted_authors):
    return _review_contract.is_trusted_bot_comment(c, trusted_authors)


def select_bot_comments(comments, trusted_authors):
    return [c for c in comments if is_trusted_bot_comment(c, trusted_authors)]


def fetch_bot_comments(repo, number, trusted_authors, run_command=None):
    """Trusted marker-source comments on the PR, across pages; None on error.

    Paginated (PRs here routinely carry 50+ bot comments; a single
    unpaginated read silently truncates). Returns None (uncertain, the caller
    fails closed) on any API/parse error or when the page cap is hit with more
    pages left.

    ``run_command`` lets a caller supply a BOUNDED runner. The default one has
    no timeout, which is right for the interactive report -- a slow read there
    is visible to the person waiting -- but wrong for a gate whose output a
    machine reads, because a hung call produces no output at all and empty
    output is not a clean result.
    """
    comments = fetch_issue_comments(
        repo,
        number,
        keep=lambda c: is_trusted_bot_comment(c, trusted_authors),
        run_command=run_command,
    )
    return None if comments is None else select_bot_comments(comments, trusted_authors)


def evaluate_reviewer_markers(comments, head_sha, bindings, only=None, authors=None):
    """Evaluate reviewer stamps and blocking markers against the current head.

    Returns a dict:
      ok        -- False when the comments could not be read (fail-closed)
      stale     -- sorted reviewer names with no fresh stamp for the head
      blocking  -- sorted reviewer names with [BLOCK-MERGE] <current head>
      findings  -- {name: advisory FINDING-line count} for fresh comments
      overridden -- {name: actor} for lanes a repository writer adjudicated at
                   this head instead of the model (see human_override_actors)
      stampless -- sorted bound lane names whose own slot carries no stamp of
                   its own AND whose body names this head: the "skipped" /
                   "could not complete" notice the advisory lanes rewrite their
                   slot to, scoped to the revision it declined. A notice left by
                   an EARLIER head excuses nothing, or a lane that DID review
                   this head and failed to upsert its verdict would read as
                   deliberately silent. Discovery mode leaves those unenrolled;
                   a PINNED caller reads this to apply the same exemption
                   without respelling it.
      seen      -- sorted bound lane names that posted a slot at all, whatever
                   it holds. A PINNED caller reads this to tell "the lane has a
                   slot and it is stale" from "the lane posted nothing", which
                   ``stale`` alone cannot: pinning seeds every named lane as
                   not-fresh, so absence and staleness arrive indistinguishable.
                   Absence has two causes that read identically HERE -- a lane
                   that deliberately had nothing to say, and one whose upsert was
                   lost -- so a caller that must not hold a head on a lane a
                   re-run cannot fill intersects ``stale`` with this.
      pinned    -- whether ``only`` named the fleet. Empty ``stale`` means
                   "every REQUIRED lane stamped this head" only when pinned;
                   in discovery mode it means "every lane that POSTED is
                   fresh", which cannot see a lane that has not spoken yet.

    STRUCTURAL INVARIANT -- reviewer identity comes from WORKFLOW-AUTHORED
    bytes, never from model output. ``bindings`` maps each lane's comment
    upsert key (the leading ``<!-- key -->`` the workflow template writes
    before any model text) to its reviewer name. A stamp counts only when a
    bound comment's OWN name matches it: stamps for other names inside a
    lane's body are injected model output and are ignored, so no lane can
    forge another reviewer's freshness regardless of what its model emits.
    Comments without a bound leading key contribute no freshness. Fail-closed
    asymmetry: a [BLOCK-MERGE] for the current head gates from ANY trusted
    comment, bound or not -- injection can deny a review, never forge one.

    Reviewers required: names in ``only`` when set (a pinned fleet -- absence
    reads as stale, so emitter drift cannot silently un-gate), else every
    BOUND reviewer that posted a comment (discovery mode; a lane that never
    posted is not required, its CI gate covers absence).

    TWO KINDS OF PROOF, and a lane is answered by either. A fresh stamp proves
    a MODEL produced a verdict for this commit. An accepted human-override
    record proves a repository WRITER adjudicated it, on a path where the model
    is deliberately not re-run, so no stamp exists to find. The stamp is
    reported as ``fresh`` and the record as ``overridden``, never folded
    together: a reader auditing the head later must be able to tell "a model
    reviewed this" from "a human cleared this". ``authors`` is the comment-author
    allowlist the record's authority rests on -- checked here as well as by the
    caller's fetch, so the function alone refuses a forged record.
    """
    if comments is None or not head_sha:
        return {
            "ok": False,
            "stale": [],
            "blocking": [],
            "findings": {},
            "elided": [],
            "overridden": {},
            "stampless": [],
            "verdicts": {},
            "pinned": only is not None,
        }
    fresh_by_name: dict = {name: False for name in (only or ())}
    findings: dict = {}
    blocking = set()
    # Whole-design lanes (Design, UX, First Principles) end their body with a
    # `<Lane>-Verdict: PASS|CONCERNS|BLOCK` line. Only BLOCK gates; CONCERNS is
    # advisory -- but an unanswered CONCERNS is the review the loop most often
    # misses, because nothing else prints it. Surface it, never gate on it.
    verdicts: dict = {}
    # Reviewers whose freshness rests on an ELIDED stamp (see sha_matches). The
    # gate accepts those, but silently swallowing them would hide the emitter
    # defect for good: nobody would learn a lane is mangling the SHA it was
    # handed. Reported as an advisory note, never as a blocking reason -- and
    # deliberately absent from progress_key, which a polling loop diffs.
    elided = set()
    # Which bound lanes hold a slot at all, and which of those carry a stamp of
    # their own. Their difference is the stampless notice the enrolment rule
    # below exempts in discovery mode, reported as ``stampless`` so a PINNED
    # caller can apply the SAME exemption instead of respelling it: under a pin
    # absence must read as stale, and a lane that wrote "I did not review this
    # head" into its own slot is an absence a re-run cannot fill. Recorded
    # outside the ``only`` filter, so the answer describes the comment set
    # rather than the pin.
    slots_seen = set()
    slots_stamped = set()
    slots_naming_head = set()
    for c in comments:
        body = c.get("body") or ""
        name = bindings.get(comment_key(body))
        stamps = REVIEWED_STAMP_RE.findall(body)
        own_stamps = [sha for stamp_name, sha in stamps if stamp_name == name] if name else []
        if name:
            slots_seen.add(name)
            if own_stamps:
                slots_stamped.add(name)
            elif any(sha_matches(sha, head_sha) for sha in BODY_SHA_RE.findall(body)):
                # The notice has to name THIS head to excuse this head. Every
                # lane writes the revision into it ("did not produce a verdict
                # for `<sha>`"), and without the check a notice left by an
                # EARLIER head excuses the current one -- so a lane that did
                # review this head and failed to upsert its verdict reads as
                # deliberately silent, and the required status passes with no
                # verdict for the revision. Any of the body's revisions counts:
                # the lane authors that sentence, a stampless body carries no
                # verdict to forge, and matching loosely here can only ever
                # keep an exemption the lane itself wrote.
                slots_naming_head.add(name)
        if name and (only is None or name in only):
            # A bound lane is held to freshness in DISCOVERY mode only when
            # its comment carries at least one of its own stamps: the UX and
            # Design workflows rewrite their keyed comment to a stampless
            # "skipped"/"could not complete" notice by design (advisory lanes
            # must not block), and enrolling those would pin exit 20 on a
            # green PR forever. A PINNED lane stays required regardless --
            # that is what pinning means.
            if only is not None or own_stamps:
                fresh = any(sha_matches(sha, head_sha) for sha in own_stamps)
                fresh_by_name[name] = fresh_by_name.get(name, False) or fresh
                if fresh:
                    findings[name] = len(FINDING_LINE_RE.findall(body))
                    if not any(head_sha.startswith(sha) for sha in own_stamps):
                        elided.add(name)
                    vm = VERDICT_LINE_RE.search(body)
                    if vm:
                        verdicts[name] = vm.group(1).upper()
        for sha in BLOCK_MERGE_RE.findall(body):
            if sha_matches(sha, head_sha):
                blocking.add(name or "(unattributed)")
    # Accepted human overrides for THIS head. A record naming one lane enrols
    # it, so that lane's presence in the set rests on the record itself rather
    # than on a stale duplicate comment; a `target=all` record answers for the
    # lanes already under evaluation without enrolling any.
    named_overrides, blanket_actor = human_override_actors(
        comments,
        head_sha,
        bindings,
        DEFAULT_MARKER_AUTHORS if authors is None else authors,
    )
    for name, actor in named_overrides.items():
        if only is None or name in only:
            fresh_by_name.setdefault(name, False)
    overridden = {}
    for name, fresh in fresh_by_name.items():
        # A fresh stamp is the stronger statement and stays the reported one:
        # the model DID run for this commit, so calling the lane overridden
        # would understate the evidence on the PR.
        if fresh:
            continue
        actor = named_overrides.get(name) or blanket_actor
        if actor:
            overridden[name] = actor
    stale = sorted(n for n, fresh in fresh_by_name.items() if not fresh and n not in overridden)
    return {
        "ok": True,
        "stale": stale,
        "blocking": sorted(blocking),
        "findings": findings,
        "elided": sorted(elided),
        "overridden": dict(sorted(overridden.items())),
        "stampless": sorted((slots_seen - slots_stamped) & slots_naming_head),
        "seen": sorted(slots_seen),
        "verdicts": verdicts,
        "pinned": only is not None,
    }


def reviewer_round_settled(marker_eval):
    """Whether AI review for this head is decided, regardless of the other checks.

    True only when the fleet was PINNED (``--reviewers`` / the loop's own
    profile names), the comments were readable, every pinned lane is answered
    for this head -- a fresh ``[<NAME>-REVIEWED]`` stamp, or an accepted human
    override record naming this head -- and at least one posted
    ``[BLOCK-MERGE]``. That combination is terminal for the head: the diff has
    to change, so the tests, packaging and lint runs still in flight are
    running on a commit that is already condemned.

    Deliberately narrow in three ways. It needs a pinned fleet, because in
    discovery mode an empty ``stale`` only says every lane that has SPOKEN is
    fresh -- a lane still composing its review is invisible, and acting on the
    first blocker would throw its verdict away. It needs a blocker, because a
    settled round with no blocker has nothing to act on and must fall through
    to the normal running/clean path. And it says nothing about failing
    non-reviewer checks: a red test while a lane is still pending stays a
    wait, so one round still fixes one full set of findings.
    """
    if not marker_eval:
        return False
    return bool(
        marker_eval.get("pinned")
        and marker_eval.get("ok")
        and not marker_eval.get("stale")
        and marker_eval.get("blocking")
    )


def head_run_exists(repo, head_sha):
    """Whether a pull_request-event workflow run exists for the current head.

    A conflicted or stale PR dispatches no pull_request workflows at all, so
    every check visible belongs to an older head and a status-only loop reports
    'nothing new' forever. The decision reads the CURRENT HEAD's own runs and
    their events -- never repo-wide history, which is wrong in both directions
    (a repo that switched to push-only triggers retains historical
    pull_request runs; a pull_request_target/workflow_run fork-safe repo never
    dispatches the event at all). Returns:
      True   -- a pull_request run exists for this head
      "skip" -- the head has runs, but its CI is driven by other events
                (push / pull_request_target / workflow_run); the PR is not
                held to an event its repo does not use for it
      False  -- an Actions-shaped rollup with NO runs for this head at all:
                the visible checks cannot belong to this head (stale)
      None   -- API error (the caller fails closed with an explicit reason)
    """
    if not repo or not head_sha:
        return None
    rc, out, _ = run(
        [
            "gh",
            "api",
            "repos/{}/actions/runs?head_sha={}&per_page=100".format(repo, head_sha),
        ]
    )
    if rc != 0 or not out:
        return None
    try:
        runs = json.loads(out).get("workflow_runs") or []
        events = {r.get("event") for r in runs if isinstance(r, dict)}
    except (ValueError, TypeError, AttributeError):
        return None
    if "pull_request" in events:
        return True
    if events:
        return "skip"
    return False


def probe_green_age(base, head_sha, pr):
    """One line on whether this head's green still describes today's base.

    INFORMATION, NEVER A GATE. The verdict is not passed to :func:`decide`, no
    exit code depends on it, and any failure inside ``green_age`` degrades to an
    "unavailable" line. A merger who is about to merge a ten-hour-old green needs
    to know the base moved underneath it; a poll cycle that could not measure
    that must not therefore call a red PR green, or a green one red.

    The base defaults to ``main`` when the host did not report one, because the
    line is advisory and a wrong default costs a wrong line, not a wrong verdict.
    """
    try:
        return _green_age.summarize(
            base=base or "main",
            head=head_sha or "HEAD",
            pr=str(pr or ""),
            runner=run,
        )
    except Exception as exc:  # noqa: BLE001 - an advisory line may never raise
        return {"ok": False, "reason": "probe failed ({})".format(type(exc).__name__)}


def green_age_line(summary):
    """The printed form of :func:`probe_green_age`, indented like its siblings."""
    return "  " + _green_age.format_line(summary)


def build_report(
    *,
    number,
    url,
    head_sha,
    readiness_kind,
    failing_checks,
    n_fail,
    n_unresolved,
    marker_eval,
    code,
    status,
    green_age=None,
    supersession_eval=None,
):
    """Build the --json report.

    Every field here has a named consumer in the babysit skill; nothing is
    emitted speculatively. The shape is split because the whole object is NOT
    safe to compare between runs:

    ``progress_key`` holds only fields that change when real progress happens,
    so a polling loop can compare it byte-for-byte to tell "still stuck" from
    "something moved". Everything unstable lives under ``advisory``, which the
    loop reads when checking its exit conditions but never includes in the
    comparison:

    * a finding a writer rebutted or deferred is re-raised every round, so a key
      including finding counts would never stabilise and a stall would never be
      recognised -- and the count also moves when a bot merely re-words a comment;
    * ``unresolved_threads`` degrades to null on any API error or page cap, so a
      transient blip would read as progress.

    Ambient PR state (mergeable, merge_state, review_decision, check totals) is
    deliberately NOT emitted: the prose above already prints all of it, the loop
    reads it there, and ``pr_findings.py`` owns the exit-20 drill-in. A second
    machine-readable copy with no reader is a surface to keep in sync for nothing.
    """
    return {
        "exit_code": code,
        "pr": number,
        "status": status,
        "url": url,
        # Compare THIS between cycles -- nothing else.
        "progress_key": {
            "checks_failing": n_fail,
            "exit_code": code,
            "failing_checks": sorted(failing_checks),
            "head_sha": head_sha,
            "readiness_kind": readiness_kind,
            # The verdict reason, so a CHANGED blocker cannot read as an
            # unchanged one. exit_code and the failing-check set do not
            # distinguish "blocked by a conflict" from "blocked by a review
            # marker": both are exit 20 and can carry an identical check set, so
            # without this a real change in what blocks the PR would extend a
            # stall streak instead of resetting it. Deterministic by
            # construction -- decide() joins its reasons in a fixed order from
            # sorted inputs.
            "status": status,
        },
        "advisory": {
            "blocking_reviewers": sorted(marker_eval.get("blocking") or []),
            "bot_comments_readable": bool(marker_eval.get("ok")),
            "elided_stamp_reviewers": sorted(marker_eval.get("elided") or []),
            "findings": dict(marker_eval.get("findings") or {}),
            # Verdicts for THIS head that a later same-head sample replaced. The
            # lanes whose block was dropped are the gating half and reach the
            # status line through decide(); these two fields are what a machine
            # reads instead of the human-only report section. `readable` false is
            # UNKNOWN, never "none found".
            "superseded_verdicts": {
                "blocking_dropped": sorted((supersession_eval or {}).get("blocking_dropped") or []),
                "lanes_seen": int((supersession_eval or {}).get("lanes_seen") or 0),
                "readable": bool((supersession_eval or {}).get("ok")),
            },
            # Advisory, and deliberately OUTSIDE progress_key: the base moving is
            # not this PR making progress, and on a repo that merges every couple
            # of minutes a commit count in the key would reset the stall streak
            # forever. The babysit trigger reads this field; the tripwire does not.
            "green_age": dict(green_age or {"ok": False, "reason": "not measured"}),
            # {lane: actor} a repository writer adjudicated at this head instead
            # of the model. Advisory and OUTSIDE progress_key for the same
            # reason the finding counts are: it is state about the head, not a
            # thing that moves when the PR makes progress. Separate from
            # stale_reviewers rather than merged into it -- a reader auditing
            # this head has to be able to tell a model verdict from a human one.
            "overridden_reviewers": dict(sorted((marker_eval.get("overridden") or {}).items())),
            "stale_reviewers": sorted(marker_eval.get("stale") or []),
            "unresolved_threads": n_unresolved,
        },
    }


def decide(
    state,
    mergeable,
    merge_state,
    decision,
    draft,
    readiness_kind,
    n_running,
    n_fail,
    n_checks,
    readiness_context,
    marker_eval=None,
    head_run="skip",
    rollup_notice="",
    disposition_eval=None,
    concerns_eval=None,
    supersession_eval=None,
):
    """Resolve PR state to (exit_code, status line). Fail-closed.

    Exit codes: 0 = clean, 10 = wait (nothing to do yet), 20 = act.

    Precedence is the load-bearing part, and it is ordered by "can waiting
    change this answer?" rather than by how the fields arrive:

    1. A non-open PR is terminal, and must be decided BEFORE any wait: GitHub
       reports mergeable=UNKNOWN for merged/closed PRs forever, so waiting on
       it returns 10 on every poll and a loop never stops.
    2. Conditions waiting CANNOT fix outrank "still running". A conflicted PR is
       the case that matters: the host cannot build a merge ref for it, so it
       dispatches no pull_request workflows at all and every check visible
       belongs to the old head. Ranking in-flight checks first reports "running"
       forever while nothing can complete -- a stall only a human notices.
       BEHIND, draft and CHANGES_REQUESTED behave the same way: each survives
       any amount of waiting and needs the author to act. A SETTLED reviewer
       round (``reviewer_round_settled``) joins them: once every pinned lane
       has stamped this head and one blocks, the edit is required, so the
       backend/frontend runs still in flight are spending minutes on a commit
       already condemned -- Phase 3 cancels them instead of waiting them out.
       Only the AI-review lanes gate this; a non-reviewer check still running
       does not hold the decision open, and a red one does not force it. The disposition
       evaluation (``disposition_eval``, built from disposition_violations)
       belongs here too, in BOTH its states: a violation is cleared only by
       the author editing or deleting the offending comment, and an
       UNREADABLE evaluation is not "no violations" -- while either waits
       behind an in-flight round, the reviewer bots rewrite their stamped
       comments in place, so the judged-head span mapping the verdict needs
       disappears with the old stamps. It gates because a record that claims
       several findings, another lane's finding, or no finding at all is
       exactly the blanket ruling the one-lane / one-rationale rule forbids
       -- and the adjudication ledger would consume it as written.
    3. Only then is "still running" a wait, and an uncomputed mergeability too.
    4. Everything left is a check-result verdict -- including the reviewer-side
       conditions: ``marker_eval`` (from evaluate_reviewer_markers; None skips
       the gate) and ``head_run`` (True/False/None from head_run_exists; the
       string "skip" skips the gate). Both are evaluated ONLY here, after the
       running gate: while a round is in flight the reviewer bots may simply
       not have posted yet, and a stale stamp mid-round is expected, not a
       defect. Both fail closed on "could not read".
       Advisory FINDING counts never gate -- whether a non-blocking finding
       should hold the loop open is a judgment call the exit code deliberately
       does not make.
       ``rollup_notice`` -- the non-empty NOTICE string when the rollup read
       degraded (fetch failure, or a concurrent push between the two reads) --
       never changes the exit code either, only which reason an empty rollup
       earns: a degraded read names its environment cause, so the reason (and
       ``progress_key.status``, which carries it) distinguishes an environment
       gap from a genuinely check-less PR.
       ``concerns_eval`` (from unanswered_concern_lanes; None skips the gate)
       belongs here for the same reason the marker conditions do: mid-round a
       fresh CONCERNS with no ruling yet is expected, not a defect -- the
       author has not been shown it. It gates only once the round has settled,
       which is exactly the state that would otherwise return 0 and arm auto-merge
       past an unanswered whole-design review. LOCAL ONLY: --disposition-gate
       never reaches this function, so the repository's required status keeps
       treating CONCERNS as advisory.
    """
    if state != "OPEN":
        return 20, "STATUS: BLOCKED - PR state is {} (not OPEN; terminal)".format(state or "?")

    blocked_now = []
    if mergeable == "CONFLICTING" or merge_state in ("DIRTY", "CONFLICTING"):
        blocked_now.append("merge conflict / not mergeable")
    if merge_state == "BEHIND":
        blocked_now.append("branch is BEHIND base - re-sync onto the latest base")
    if draft:
        blocked_now.append("PR is a draft")
    if decision == "CHANGES_REQUESTED":
        blocked_now.append("review decision is CHANGES_REQUESTED")
    if reviewer_round_settled(marker_eval):
        # The reviewer round is DONE even though the rollup is not: every
        # pinned lane stamped this head and at least one blocks. Waiting for
        # the remaining lanes (backend/frontend tests, packaging) cannot
        # change that the diff must be edited, and their verdicts do not
        # survive the edit anyway -- the push re-runs them on the new head.
        # So this belongs with the other "waiting cannot fix this" conditions
        # ABOVE the running gate. Requires a PINNED fleet: discovery mode
        # cannot tell "all lanes reported" from "one lane reported first",
        # and acting there would drop a verdict that was still coming.
        blocked_now.append(
            "reviewer round complete with blocking marker [BLOCK-MERGE] on "
            "current head from: " + ", ".join(sorted(marker_eval["blocking"]))
        )
    if disposition_eval is not None:
        # A disposition violation is a condition waiting cannot fix -- only the
        # AUTHOR editing or deleting the comment clears it -- so it belongs
        # with the other author-action conditions ABOVE the running gate.
        # Deferring it behind an in-flight round loses the evidence: the
        # reviewer bots rewrite their stamped comments in place when the round
        # completes, and the judged-head span mapping the violation was
        # computed from disappears with the old stamps. An UNREADABLE
        # evaluation (records or the finding map could not be fetched) gates
        # here for the same reason: "could not read" is not "no violations",
        # and waiting through the round destroys the very evidence a re-read
        # would need. Sorted by construction (disposition_violations returns a
        # sorted list), so the joined reason -- which travels in
        # ``progress_key.status`` -- is deterministic.
        if not disposition_eval.get("ok"):
            blocked_now.append("disposition records could not be established (fail-closed)")
        for v in disposition_eval.get("violations") or []:
            blocked_now.append("disposition rule: " + v)
    if blocked_now:
        return 20, "STATUS: BLOCKED - " + "; ".join(blocked_now)

    # An observed running lane keeps the round open regardless of the
    # aggregate. The aggregate's context name is a forgeable display string, so
    # if a passed aggregate could conclude the "still running" gate, a forged
    # green posted while a real lane is still QUEUED/IN_PROGRESS would skip this
    # branch and reach CLEAN before the real failure lands -- the same
    # forged-green-to-CLEAN vector, moved into a timing window. So an observed
    # running row means RUNNING on its own terms, and a failing aggregate is
    # reported below. The aggregate subtracts neither a pending nor a failing
    # row.
    if readiness_kind == "running" or n_running > 0:
        return 10, "STATUS: RUNNING (round not complete)"
    if mergeable not in ("MERGEABLE", "CONFLICTING"):
        return 10, "STATUS: RUNNING (mergeability not yet computed: {})".format(
            mergeable or "UNKNOWN"
        )

    reasons = []
    # An observed failing row is authoritative on its own terms: a passed
    # aggregate does not clear it. The aggregate's context name is a display
    # string any status publisher on the pull request can set, so letting a
    # green aggregate erase a failing row would let a forged green flip this
    # tool to CLEAN over a real failure. So report a failing row whenever one
    # exists, independent of the aggregate, and report a failing aggregate as
    # its own reason. The aggregate subtracts no observed row -- neither a
    # pending one (handled by the running gate above) nor a failing one here.
    if readiness_kind == "fail":
        reasons.append("{} reported action required".format(readiness_context))
    if n_fail > 0:
        reasons.append("{} check(s) failed".format(n_fail))
    if n_checks == 0:
        # An empty rollup has two very different causes, and the reason chosen
        # here travels in ``progress_key.status``, which a polling loop
        # compares byte-for-byte across runs. A degraded rollup read (the
        # NOTICE the caller printed) is an environment gap -- token scope, an
        # API error, a concurrent push -- while an empty rollup from a healthy
        # read means the host truly reports no checks for this head. One
        # shared reason would make those indistinguishable, so a loop would
        # re-poll a token problem forever instead of escalating it.
        if rollup_notice == ROLLUP_HEAD_MOVED_NOTICE:
            reasons.append(
                "CI status unreadable - the PR head moved between reads "
                "(concurrent push) - transient environment, re-run for a "
                "consistent snapshot (fail-closed)"
            )
        elif rollup_notice:
            reasons.append(
                "CI status unreadable - the rollup fetch failed (a token "
                "without Checks read access, a 403, or a rate limit) - "
                "environment gap, not a code defect (fail-closed)"
            )
        else:
            reasons.append("no CI checks reported - cannot confirm CI (fail-closed)")
    if marker_eval is not None:
        if not marker_eval.get("ok"):
            reasons.append("reviewer comments could not be read (fail-closed)")
        else:
            if marker_eval.get("blocking"):
                # sorted(): ``blocking`` is a set, and joining a set of strings
                # is only order-stable WITHIN one process. This status string is
                # part of progress_key, which a polling loop compares
                # byte-for-byte across separate runs, so an unsorted join would
                # make two identical states differ whenever more than one
                # reviewer blocks.
                reasons.append(
                    "blocking review marker [BLOCK-MERGE] on current head from: "
                    + ", ".join(sorted(marker_eval["blocking"]))
                )
            if marker_eval.get("stale"):
                reasons.append(
                    "stale reviewer stamp(s) - no [<NAME>-REVIEWED] for current head: "
                    + ", ".join(marker_eval["stale"])
                )
    for lane in (concerns_eval or {}).get("unanswered") or []:
        reasons.append(
            unanswered_concerns_reason(lane, (concerns_eval or {}).get("head_sha") or "")
        )
    # A block this lane raised for THIS head, replaced by a later sample that does
    # not block. Waiting cannot fix it -- the replacement already happened -- so it
    # is an act reason, matching what the required status does with the same field.
    #
    # An UNREADABLE evaluation gates here too, exactly as the marker and
    # disposition evaluations above do: "could not read the stored history" is not
    # "no verdict was superseded", and this exit code is what arms `gh pr merge
    # --auto`, so failing open here would let one transient GraphQL failure arm
    # auto-merge over a dropped review block. The printed report already calls this
    # state "fail-closed - this is not a clean result"; without this branch the
    # exit code contradicted its own report. It sits BELOW the running gate rather
    # than in ``blocked_now`` because an unreadable history is transient and
    # waiting genuinely can fix it -- unlike a disposition violation, which only
    # the comment's author can clear.
    #
    # This is not the required status's rule and does not change it: there,
    # ``ok=false`` maps to `pending`, never to a red, because a status that turns
    # "I could not answer" into a failure blocks every writer on a transient. The
    # two surfaces answer different questions -- "is this revision red" versus
    # "may this loop arm auto-merge" -- and UNKNOWN answers no to the second.
    #
    # Scoped to cause="unreadable", the read that FAILED on a lane that exists.
    # The other cause, an empty population, is already covered here: the
    # supersession read only runs when the markers were readable, so zero lanes
    # examined means no bound lane comment exists, and "no [<NAME>-REVIEWED] for
    # current head" above is the reason that states it. Failing closed on that too
    # would add a second voice for one condition and report BLOCKED on every pull
    # request whose reviewers have not commented yet, for a population where
    # nothing could have been superseded.
    if supersession_eval is not None and supersession_eval.get("cause") == "unreadable":
        reasons.append(
            "superseded review verdicts could not be established (fail-closed) - "
            + (supersession_eval.get("error") or "supersession could not be evaluated")
        )
    for lane in (supersession_eval or {}).get("blocking_dropped") or []:
        # Both halves of this text were wrong and each sent the reader somewhere
        # the code does not look. `/ai-review override <lane> <head>` is an exit
        # for EVERY lane, not a new head, and on a fork PR too: the accepted
        # record itself adjudicates every block the lane raised at this head
        # before it was recorded (superseded_verdicts reads it), and the
        # lane's override arm, same-repo and fork alike, also replaces the slot
        # with a note that carries no `[<LANE>-REVIEWED] <head>` stamp, so
        # `current_stamped` goes False. And
        # what clears the GPT family by decision is the workflow-authored
        # `(all downgraded on adjudication)` heading, NOT the
        # `[BLOCK-MERGE-DOWNGRADED]` marker: _sanctioned_downgrade reads the
        # heading precisely because the marker sits in embedded model output.
        # Naming a new head first is the expensive advice, since it discards every
        # other lane's verdict for this head.
        if lane.upper() in _review_contract.DOWNGRADE_LANES:
            remedy = (
                "if the clear is legitimate, record it at this head: "
                "/ai-review override, or an adjudication pass, whose "
                "'(all downgraded on adjudication)' heading is read here as "
                "cleared. Pushing a new head also re-samples it, at the cost of "
                "every other lane's verdict for this head"
            )
        else:
            remedy = (
                "if the clear is legitimate, record it at this head with "
                "/ai-review override, whose accepted record adjudicates every "
                "block this lane raised at this head before it, on a fork PR "
                "too. This lane has no "
                "adjudication heading, so the only other exit is a new head, at "
                "the cost of every other lane's verdict for this head"
            )
        reasons.append(
            "superseded verdict: {} blocked this head in a replaced sample and the "
            "body now presented does not - read the comment's stored history; "
            "{}".format(lane, remedy)
        )
    if head_run is False:
        reasons.append(
            "no pull_request-event workflow run for the current head - the "
            "checks shown may belong to an older head (stale or conflicted PR)"
        )
    elif head_run is None:
        reasons.append(
            "could not confirm a pull_request-event run for the current head (fail-closed)"
        )
    if merge_state and merge_state not in (
        "CLEAN",
        "HAS_HOOKS",
        "UNSTABLE",
        "BLOCKED",
        "DIRTY",
        "CONFLICTING",
        "DRAFT",
        "BEHIND",
    ):
        # BLOCKED = pending required review (expected for a review-ready PR);
        # anything unrecognized is fail-closed.
        reasons.append("unrecognized merge state '{}' (fail-closed)".format(merge_state))

    if reasons:
        return 20, "STATUS: BLOCKED - " + "; ".join(reasons)
    return 0, "STATUS: CLEAN (readiness passed, mergeable, no blocking review decision)"


def _flag_value(argv, name):
    """Value of ``--name VALUE`` or ``--name=VALUE`` in argv, else ""."""
    for i, a in enumerate(argv):
        if a == name and i + 1 < len(argv):
            return argv[i + 1]
        if a.startswith(name + "="):
            return a.split("=", 1)[1]
    return ""


def disposition_gate(argv, environ):
    """Evaluate the reviewer-record rules the required status needs; exit 0.

    This is the server-side entry point: pr-readiness.yml calls
    it so a disposition record violating the one-lane / one-rationale-per-
    finding rule fails the repository's required status for EVERY writer, not
    only for a writer running the kirocrew-prepare-pr loop. It exists as a mode of this
    script rather than as a workflow-side reimplementation so the rule keeps a
    single definition -- the same ``disposition_violations`` the local gate
    calls, over the same records the adjudication ledger admits.

    TWO questions, one trusted comment read, because they are answered from the
    same set: the disposition rule, and which whole-design lanes owe this head a
    verdict they never published (``unpublished``). A lane that reports
    ``success`` having failed to write its comment is otherwise indistinguishable
    from a reviewed one on the server side, and scoring it as reviewed is what
    let the required status read green while this script read BLOCKED.

    Usage: --disposition-gate --repo OWNER/NAME --pr N --head SHA
    (--marker-bindings / --marker-authors and their env forms apply as usual.)

    Prints ``{"ok", "violations", "unpublished", "comments", "records",
    "unverified", "error"}``. ``ok`` is False when the record set could not be
    established, which the caller must treat as UNKNOWN (pending) rather than as
    a red: a transient API failure red-lighting the required status is that class
    of bug. Exit status is 0 for both outcomes -- the JSON carries the verdict,
    so a non-zero exit means only that this script itself failed to run, and
    the caller can tell the two apart. Enforcement scope is deliberately
    identical to the ledger's admission scope: an author the collaborators
    permission API does not confirm as a writer is DROPPED here exactly as
    codex-review.yml drops them, so this gate never blocks on a record that
    holds no downgrade power (``unverified`` counts those, for observability).
    """
    repo = _flag_value(argv, "--repo").strip()
    number = _flag_value(argv, "--pr").strip()
    head_sha = _flag_value(argv, "--head").strip()
    result = {
        "ok": False,
        "violations": [],
        "comments": 0,
        "records": 0,
        "unverified": 0,
        "unpublished": [],
        "error": "",
    }
    try:
        if not repo or not number or not head_sha:
            result["error"] = "--repo, --pr and --head are all required"
        else:
            bindings = resolve_marker_bindings(argv, environ)
            # ONE paginated read serves both selectors: this mode runs on
            # every full readiness evaluation, and the hourly GITHUB_TOKEN
            # pool every workflow here shares is what it would otherwise
            # spend walking the same comment pages twice.
            # Filtered page by page, so a comment neither selector wants is
            # never retained.
            authors = resolve_marker_authors(argv, environ)
            all_comments = fetch_issue_comments(
                repo,
                number,
                keep=lambda c: (
                    _review_contract.is_disposition_comment(c) or is_trusted_bot_comment(c, authors)
                ),
            )
            comments = bot_comments = None
            if all_comments is not None:
                comments = _review_contract.select_disposition_comments(all_comments)
                bot_comments = select_bot_comments(all_comments, authors)
            records = writer_disposition_records(repo, comments)
            if comments is None or bot_comments is None or records is None:
                result["error"] = "disposition or marker comments could not be read"
            else:
                result["comments"] = len(comments)
                result["records"] = len(records)
                result["unverified"] = len(comments) - len(records)
                # One violation per line downstream, so a newline inside one
                # would forge an extra blocker line. Nothing in the strings can
                # carry one today (logins, span ids and target= are all charset-
                # limited), which is exactly why flattening here is free.
                result["violations"] = [
                    " ".join(sanitize(v).split())
                    for v in disposition_violations(records, bot_comments, head_sha, bindings)
                ]
                # The whole-design lanes that owe this head a verdict and have
                # none. Free here: the trusted comment set is already read, and
                # ``evaluate_reviewer_markers`` is the definition both gates
                # answer from, so the required status and ``pr_status.py``
                # cannot disagree about a head.
                #
                # PINNED on the lane set, not discovered from what posted: a
                # lane whose FIRST publish fails leaves no slot at all, and
                # discovery cannot see a lane that has not spoken, so the
                # absence would score as reviewed -- the same fail-open one
                # round later, reached by a PR's ordinary first round. Under a
                # pin, absence reads as stale, which is the whole point.
                #
                # Two exemptions survive the pin, and neither is respelled
                # here. A lane a writer adjudicated at this head is already out
                # of ``stale`` (the override path does not re-run the model, so
                # no stamp can exist). A lane holding a stampless notice THAT
                # NAMES THIS HEAD is ``stampless`` -- it said it did not review
                # this head, and a re-run produces the same notice, so holding
                # it would strand a green PR on a lane nothing can fill. A
                # notice naming an earlier head is not an answer for this one.
                #
                # Scoped to slots that EXIST: a lane with no slot at all is not
                # reported here. Absence has two causes that read identically
                # from the comments -- a lane that published nothing because it
                # deliberately had nothing to say, and one whose upsert was
                # lost -- and only the lane itself can tell them apart, by
                # leaving a notice. Reporting absence without that would hold
                # every backend-only revision on a lane a re-run cannot fill.
                # Closing that half means giving the scope-skip arms a notice to
                # write, which is a change to those lanes, not to this reader.
                markers = evaluate_reviewer_markers(
                    bot_comments,
                    head_sha,
                    bindings,
                    only=WHOLE_DESIGN_LANES,
                    authors=resolve_marker_authors(argv, environ),
                )
                exempt = set(markers["stampless"])
                present = set(markers["seen"])
                result["unpublished"] = [
                    name for name in markers["stale"] if name not in exempt and name in present
                ]
                result["ok"] = True
    except Exception as exc:  # noqa: BLE001 - any failure is "unknown", never red
        result["error"] = "{}: {}".format(type(exc).__name__, exc)
    print(json.dumps(result, sort_keys=True))
    return 0


# A gate's output is read by a machine, and empty output is not a clean result:
# a caller wrapping it in `timeout 60` gets rc=124 and an empty stdout, which is
# indistinguishable from a gate that answered "nothing found" unless the caller
# knows to check. `run` has no timeout, which is right for the interactive report
# and wrong here, so the gate path gets its own bounded runner and an overall
# budget. Together they guarantee the gate PRINTS, within roughly the budget plus
# one call, whatever the network does.
_GATE_CALL_TIMEOUT_SECS = 20
_GATE_TOTAL_BUDGET_SECS = 45


def bounded_run(args, timeout=_GATE_CALL_TIMEOUT_SECS):
    """``run`` with a per-call wall-clock bound; 124 and a reason on timeout."""
    try:
        p = subprocess.run(
            args,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
        return p.returncode, p.stdout.strip(), p.stderr.strip()
    except subprocess.TimeoutExpired:
        return 124, "", "{}: no answer within {}s".format(args[0], timeout)
    except OSError as exc:
        return 127, "", "{}: {}".format(args[0], exc)


def supersession_gate(argv, environ):
    """Report verdicts for one head that a later sample at the same head replaced.

    A lane's marker comment is one slot keyed on the lane alone, so a second
    sample at one head overwrites the first and the board keeps only the
    survivor. Every body the slot held survives in GraphQL userContentEdits, so
    this gate reads that history rather than adding a record to it.

    Usage: --supersession-gate --repo OWNER/NAME --pr N --head SHA
    (--marker-bindings / --marker-authors and their env forms apply as usual.)

    Prints ``{"ok", "blocking_dropped", "superseded", "lanes_seen", "lanes",
    "error"}``. ``superseded`` is the total count of replaced same-head samples,
    ``lanes_seen`` is how many lanes were examined, and ``blocking_dropped``
    names the lanes where a replaced sample BLOCKED this head and the presented
    body does not -- the only direction that can turn a judged block into a clean
    board. A sample blocks in either spelling the lanes use, ``[BLOCK-MERGE]
    <head>`` or a whole-design ``<Lane>-Verdict: BLOCK`` line. A presented body
    whose workflow-authored heading says adjudication downgraded this head is a
    SANCTIONED clear and is not named.

    ``ok`` False means UNKNOWN and must be treated as pending, never as "nothing
    was superseded". It covers an unreadable history, a head where NO lane was
    examined, and the reads not finishing inside the gate's own time budget --
    because a clean answer over an empty population, and no answer at all, are
    both calm reported from having observed nothing. Every call is bounded and the
    whole gate is bounded, so it always prints. Exit status is 0 for both
    outcomes, so a non-zero exit means this script itself failed to run.
    """
    repo = _flag_value(argv, "--repo").strip()
    number = _flag_value(argv, "--pr").strip()
    head_sha = _flag_value(argv, "--head").strip()
    result = {
        "ok": False,
        "blocking_dropped": [],
        "superseded": 0,
        "lanes_seen": 0,
        "lanes": [],
        "error": "",
    }
    try:
        if not repo or not number or not head_sha:
            result["error"] = "--repo, --pr and --head are all required"
        else:
            deadline = time.monotonic() + _GATE_TOTAL_BUDGET_SECS
            bindings = resolve_marker_bindings(argv, environ)
            authors = resolve_marker_authors(argv, environ)
            comments = fetch_bot_comments(repo, number, authors, bounded_run)
            if comments is None:
                result["error"] = "bot comments could not be read"
            else:
                found = superseded_verdicts(
                    comments, head_sha, bindings, bounded_run, authors, deadline
                )
                result["ok"] = bool(found["ok"])
                result["error"] = found["error"]
                result["blocking_dropped"] = found["blocking_dropped"]
                result["lanes"] = found["lanes"]
                result["lanes_seen"] = found["lanes_seen"]
                result["superseded"] = sum(len(e["superseded"]) for e in found["lanes"])
    except Exception as exc:  # noqa: BLE001 - any failure is "unknown", never red
        result["ok"] = False
        result["error"] = "{}: {}".format(type(exc).__name__, exc)
    print(json.dumps(result, sort_keys=True))
    return 0


def main(argv):
    # Before the auth probe and PR detection below: this mode is given its
    # repo/PR/head explicitly and must stay usable from a workflow runner,
    # where `gh auth status` prose is noise and the JSON is the whole output.
    if "--disposition-gate" in argv[1:]:
        return disposition_gate(argv, os.environ)

    if "--supersession-gate" in argv[1:]:
        return supersession_gate(argv, os.environ)

    if run(["gh", "auth", "status"])[0] != 0:
        err("ERROR: gh not found or not authenticated. Run: gh auth login")
        return 2

    readiness_context = resolve_readiness_context(argv, os.environ)
    reviewers_filter = resolve_reviewers(argv, os.environ)
    pos = positional_args(argv[1:])
    pr = pos[0] if pos else ""
    if not pr:
        pr = run(["gh", "pr", "view", "--json", "number", "-q", ".number"])[1]
    if not pr:
        err("ERROR: no PR number given and none found for the current branch.")
        return 2

    fields = (
        "number,title,state,isDraft,mergeable,mergeStateStatus,"
        "reviewDecision,url,headRefName,headRefOid,baseRefName,"
        "body,closingIssuesReferences"
    )
    rc, out, _ = run(["gh", "pr", "view", pr, "--json", fields])
    if rc != 0 or not out:
        err("ERROR: could not read PR #" + str(pr))
        return 2
    d = json.loads(out)

    state = (d.get("state") or "").upper()
    draft = bool(d.get("isDraft"))
    mergeable = (d.get("mergeable") or "").upper()
    merge_state = (d.get("mergeStateStatus") or "").upper()
    decision = (d.get("reviewDecision") or "NONE").upper()
    head_sha = (d.get("headRefOid") or "").strip()
    # The viewed PR's own repository: the rollup read addresses it by owner,
    # name and number, and the positional argument may be a URL for a repository
    # other than the cwd's checkout.
    repo = detect_repo(d.get("url") or "")
    rollup_entries, rollup_notice = fetch_check_rollup(repo, d.get("number"), head_sha)
    rollup = collapse_superseded(rollup_entries)

    print("=" * 54)
    print("PR #{}  [{}{}]".format(d.get("number"), state, " draft" if draft else ""))
    print("title (untrusted): " + sanitize(d.get("title") or ""))
    print("branch: " + sanitize(d.get("headRefName") or ""))
    print("url:    " + (d.get("url") or ""))
    print(
        "mergeable={}  mergeState={}  reviewDecision={}".format(
            mergeable or "?", merge_state or "?", decision
        )
    )

    print("-- CI checks " + "-" * 40)
    if rollup_notice:
        print("  NOTICE: " + rollup_notice)
    n_running = n_fail = 0
    failing_checks = []
    readiness_kind = None
    for e in rollup:
        kind = classify_check(e)
        if kind == "running":
            n_running += 1
        elif kind == "fail":
            n_fail += 1
        name = sanitize(e.get("name") or e.get("context") or "check")
        if kind == "fail":
            failing_checks.append(failing_check_identity(e))
        # Only the legacy StatusContext we publish is authoritative. A CheckRun
        # can share the display name but is a different, independently writable
        # namespace and must remain part of the ordinary rollup.
        if e.get("context") == readiness_context:
            readiness_kind = kind
        shown = (e.get("status") or "-") + "/" + (e.get("conclusion") or e.get("state") or "-")
        print("  - {}: {}  [{}]".format(name, shown, kind))
    print("  rollup: total={} running={} failing={}".format(len(rollup), n_running, n_fail))
    print("  aggregate readiness: {}".format(readiness_kind or "not published"))
    _closes = d.get("closingIssuesReferences") or []
    print(
        "  closes on merge: {}".format(
            ", ".join("#{}".format(i.get("number")) for i in _closes) if _closes else "nothing"
        )
    )
    # Advisory, never a gate. The measured failure was that nobody was ever
    # ASKED for a trailer, not that authors refuse to write one: across 600
    # merged PRs the host's auto-close worked every time it had a keyword to
    # act on. So report the gap where the author will see it and let them
    # decide -- blocking a green PR on bookkeeping costs more than it saves,
    # and an issue-less PR is legitimate.
    _closing = closing_link_reason(d.get("body"), _closes, repo)
    if _closing:
        print("  NOTICE: " + _closing)

    n_unresolved = unresolved_thread_count(d.get("number"))
    print("-- Review threads " + "-" * 35)
    print(
        "  unresolved threads (advisory): " + ("?" if n_unresolved is None else str(n_unresolved))
    )

    # Reviewer-side conditions: the stamp and the comment body
    # are the signal -- never the review workflow's run conclusion, which is
    # unreliable in both directions on this repo.
    marker_authors = resolve_marker_authors(argv, os.environ)
    marker_bindings = resolve_marker_bindings(argv, os.environ)
    bot_comments = fetch_bot_comments(repo, d.get("number"), marker_authors)
    marker_eval = evaluate_reviewer_markers(
        bot_comments,
        head_sha,
        marker_bindings,
        only=reviewers_filter,
        authors=marker_authors,
    )
    print("-- Reviewer markers (head {}) ".format(sanitize(head_sha[:12]) or "?") + "-" * 20)
    if not marker_eval["ok"]:
        print("  ERROR: bot comments could not be read (fail-closed)")
    elif (
        not marker_eval["findings"]
        and not marker_eval["stale"]
        and not marker_eval.get("overridden")
    ):
        if reviewers_filter:
            print(
                "  (no [<NAME>-REVIEWED] stamps found for filter: "
                + ", ".join(sorted(reviewers_filter))
                + ")"
            )
        else:
            print("  (no [<NAME>-REVIEWED] stamps found in bot comments)")
    else:
        for name in sorted(marker_eval["findings"]):
            print(
                "  - {}: fresh{}{}{}{}".format(
                    sanitize(name),
                    "  [BLOCK-MERGE]" if name in marker_eval["blocking"] else "",
                    (
                        "  ({} advisory FINDING line(s))".format(marker_eval["findings"][name])
                        if marker_eval["findings"][name]
                        else ""
                    ),
                    (
                        "  [stamp elided the head's middle - emitter transcription "
                        "artifact, verified against this head]"
                        if name in (marker_eval.get("elided") or ())
                        else ""
                    ),
                    (
                        "  verdict={}{}".format(
                            marker_eval["verdicts"][name],
                            (
                                "  <- whole-design review: answer per item, and read it "
                                "BEFORE fixing line-level findings"
                                if marker_eval["verdicts"][name] == "CONCERNS"
                                else ""
                            ),
                        )
                        if name in (marker_eval.get("verdicts") or {})
                        else ""
                    ),
                )
            )
        for name in marker_eval["stale"]:
            print("  - {}: STALE (stamp names an older head)".format(sanitize(name)))
        # Named distinctly from `fresh`, because the two are different
        # evidence: no model verdict exists for this head, and the row must not
        # read as though one does.
        for name, actor in sorted((marker_eval.get("overridden") or {}).items()):
            print(
                "  - {}: OVERRIDDEN by @{} (human judgment recorded for this head; "
                "the model was not re-run)".format(sanitize(name), sanitize(actor))
            )

    # Each whole-design lane's punchline, read from the lane bodies rather than
    # from the marker rows above: a pinned fleet such as `--reviewers gpt,opus`
    # lists no whole-design lane there, and on a PASS the punchline is the lane's
    # one ask. Printed every cycle so a green head cannot hide it. Advisory: it
    # changes no exit code.
    if marker_eval.get("ok") and bot_comments is not None:
        punchlines = design_lane_punchlines(bot_comments, head_sha, marker_bindings)
        lane_verdicts = design_lane_verdicts(bot_comments, head_sha, marker_bindings)
        print("-- Whole-design punchlines, untrusted (head {}) --".format(sanitize(head_sha[:12])))
        if not punchlines:
            print("  (none to check on this head)")
        for name in sorted(punchlines):
            print(
                "  - {} ({}): {}".format(
                    sanitize(name),
                    sanitize(lane_verdicts.get(name) or "?"),
                    sanitize(redact(punchlines[name]))[:280],
                )
            )

    # Disposition-rule gate: a repository writer's disposition
    # comment must claim exactly one span= finding identity from its own
    # target= lane. Each record is validated against the findings stamped for
    # the head its head= says it judged (in the ordinary fix-then-push round
    # that is the PRIOR head) and the current one, so the rule "one comment
    # covers one lane, one rationale covers one finding" is mechanical rather
    # than prose.
    disposition_comments = fetch_disposition_comments(repo, d.get("number"))
    disposition_records = writer_disposition_records(repo, disposition_comments)
    disposition_violation_list: list = []
    # BOTH inputs must be readable: the records (the rulings) and the trusted
    # reviewer comments (the finding map the rulings are validated against).
    # An unreadable finding map is not "no findings" -- computing with an
    # empty map would silently drop every evidence-bearing class while the
    # round runs, and the judged-head evidence is rewritten in place when it
    # completes.
    disposition_ok = disposition_records is not None and bot_comments is not None
    if disposition_ok:
        disposition_violation_list = disposition_violations(
            disposition_records, bot_comments, head_sha, marker_bindings
        )
    disposition_eval = {"ok": disposition_ok, "violations": disposition_violation_list}
    # A whole-design lane at CONCERNS for this head with no matching
    # disposition record is the review the loop most often walked past: the
    # rollup is green, so exit 0 armed auto-merge over it. Requires BOTH reads
    # to have succeeded -- an unreadable side already gates above, and guessing
    # "no CONCERNS" from an unread comment list is the wrong direction.
    concerns_eval = None
    if marker_eval.get("ok") and disposition_records is not None:
        concerns_eval = {
            "unanswered": unanswered_concern_lanes(
                marker_eval.get("verdicts") or {}, disposition_records, head_sha
            ),
            "head_sha": head_sha,
        }
    # A second sample at ONE head replaces the first in the lane's slot, so the
    # board keeps only the survivor and the replaced verdict is presented
    # nowhere. Report it here from the stored history rather than leaving the
    # local loop to infer it. Costs one GraphQL read per bound lane, so it runs
    # only when the markers themselves were readable -- with those unread there
    # is no lane set to ask about.
    supersession_eval = None
    if marker_eval.get("ok") and bot_comments is not None:
        supersession_eval = superseded_verdicts(
            bot_comments, head_sha, marker_bindings, run, marker_authors
        )
        print("-- Superseded verdicts (head {}) ".format(sanitize(head_sha[:12]) or "?") + "-" * 17)
        if not supersession_eval["ok"]:
            print(
                "  UNKNOWN: {} (fail-closed - this is not a clean result)".format(
                    sanitize(supersession_eval["error"] or "supersession could not be evaluated")
                )
            )
        else:
            replaced = [e for e in supersession_eval["lanes"] if e["superseded"]]
            if not replaced:
                print(
                    "  (no verdict for this head was replaced by a later sample; "
                    "{} lane(s) examined)".format(supersession_eval["lanes_seen"])
                )
            for entry in replaced:
                for sample in entry["superseded"]:
                    print(
                        "  - {}: sample at {} was replaced{}{}{}".format(
                            sanitize(entry["lane"]),
                            sanitize(sample["at"]),
                            "  [BLOCK-MERGE]" if sample["blocking"] else "",
                            (
                                "  verdict {}".format(sanitize(sample["verdict"]))
                                if sample["verdict"]
                                else ""
                            ),
                            (
                                "  ({} FINDING line(s))".format(sample["findings"])
                                if sample["findings"]
                                else ""
                            ),
                        )
                    )
            for lane in supersession_eval["blocking_dropped"]:
                print(
                    "  BLOCKING DROPPED: {} blocked this head in a replaced sample and "
                    "the body now presented does not - read the history before "
                    "treating this lane as clear".format(sanitize(lane))
                )

    print("-- Disposition records (one lane, one rationale per finding) " + "-" * 6)
    if not disposition_ok:
        print("  ERROR: disposition records could not be established (fail-closed)")
    elif not disposition_comments:
        print("  (no disposition comments)")
    else:
        # Both counts, so a degraded state is visible instead of reading like
        # an empty PR: zero verified records above a non-zero comment count
        # means the check is INERT for those comments -- non-writer authors,
        # or a token that cannot read collaborator permissions (the endpoint
        # needs push access).
        print(
            "  disposition-marked comment(s): {}  from verified writers: {}".format(
                len(disposition_comments), len(disposition_records)
            )
        )
        if not disposition_records:
            print(
                "  NOTICE: none verified as a repository writer's - the "
                "disposition check is inert for these comments"
            )
        unknown_targets = sorted(
            {
                r["target"]
                for r in disposition_records
                if not r["malformed"]
                and r["target"] not in {n.lower() for n in marker_bindings.values()}
            }
        )
        if unknown_targets:
            # Advisory only: an unbound lane (e.g. first-principles) has no
            # extractable finding identity, but a typo'd target= looks the
            # same and silently escapes the claim requirement -- say so.
            print(
                "  NOTICE: target lane(s) outside the marker bindings "
                "(claim checks do not apply): " + ", ".join(sanitize(t) for t in unknown_targets)
            )
        for v in disposition_violation_list:
            print("  VIOLATION: " + sanitize(v))
        if not disposition_violation_list:
            print("  (no disposition-rule violations)")
    for lane in (concerns_eval or {}).get("unanswered") or []:
        print(
            "  UNANSWERED: {} reported CONCERNS for this head and no "
            "target={} disposition record names it - run pr_findings.py for "
            "the Watch/Subtraction items and their span ids".format(
                sanitize(lane), sanitize(lane.lower())
            )
        )

    # Assert a pull_request-event run exists for the current head, but only on
    # a PR that demonstrably uses Actions (a rollup entry with a workflowName);
    # a repo reporting only legacy statuses must not be blocked forever by an
    # assertion about workflows it does not run.
    head_run = "skip"
    if (
        head_sha
        and any(e.get("workflowName") for e in rollup)
        and head_run_check_enabled(argv, os.environ)
    ):
        head_run = head_run_exists(repo, head_sha)
        if head_run is True:
            run_shown = "yes"
        elif head_run is False:
            run_shown = "NO (stale or conflicted?)"
        elif head_run == "skip":
            run_shown = "n/a (this head's CI is driven by other events)"
        else:
            run_shown = "? (could not confirm)"
        print("  pull_request run for current head: " + run_shown)
    # Whether that run's verdict still describes today's base. Printed beside the
    # rollup because it qualifies the rollup: a green measured on a base that has
    # since moved in this PR's own files is a green about a tree nobody has.
    green_age = probe_green_age(d.get("baseRefName") or "", head_sha, d.get("number"))
    print(green_age_line(green_age))
    print("=" * 54)

    code, status = decide(
        state=state,
        mergeable=mergeable,
        merge_state=merge_state,
        decision=decision,
        draft=draft,
        readiness_kind=readiness_kind,
        n_running=n_running,
        n_fail=n_fail,
        n_checks=len(rollup),
        readiness_context=readiness_context,
        marker_eval=marker_eval,
        head_run=head_run,
        rollup_notice=rollup_notice,
        disposition_eval=disposition_eval,
        concerns_eval=concerns_eval,
        supersession_eval=supersession_eval,
    )
    print(status)
    if "--json" in argv[1:]:
        # Last line of stdout, one compact line, keys sorted: a polling loop
        # compares consecutive runs byte-for-byte, so the serialization has to
        # be stable for an unchanged PR.
        print(
            json.dumps(
                build_report(
                    number=d.get("number"),
                    url=d.get("url") or "",
                    head_sha=head_sha,
                    readiness_kind=readiness_kind,
                    failing_checks=failing_checks,
                    n_fail=n_fail,
                    n_unresolved=n_unresolved,
                    marker_eval=marker_eval,
                    code=code,
                    status=status,
                    green_age=green_age,
                    supersession_eval=supersession_eval,
                ),
                sort_keys=True,
                separators=(",", ":"),
            )
        )
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv))
